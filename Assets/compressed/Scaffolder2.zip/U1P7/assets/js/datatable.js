
	$(document).ready(function () {
		
	$('#dtTipoUsuario').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtUsuario').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtEntidadSeguridad').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtAccionSeguridad').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtSeguridad').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtProyecto').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtEntidad').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtCampo').DataTable({
		"pagingType": "full_numbers" 
	});
	$('.dataTables_length').addClass('bs-select');
});
