<?php
include_once "database.php";

Class CampoModel {

	private $id;
	private $Nombre;
	private $Longitud;
	private $EsNull;
	private $Tipo;
	private $EsVisible;
	private $ValorDefault;
	private $Entidad;
	private $FechaCreacion;
	private $FechaUltimaModificacion;
	private $RelacionEntidad;
	private $RelacionEntidadCampo;
	private	$db;

	function __construct (){

	  	$this->db="scaffolder2";
    	
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getId(){
		return $this->id;
	}

	
	public function getNombre(){
		return $this->Nombre;
	}

	public function setNombre($Nombre){
		$this->Nombre = $Nombre;
	}

	
	public function getLongitud(){
		return $this->Longitud;
	}

	public function setLongitud($Longitud){
		$this->Longitud = $Longitud;
	}

	
	public function getEsNull(){
		return $this->EsNull;
	}

	public function setEsNull($EsNull){
		$this->EsNull = $EsNull;
	}

	
	public function getTipo(){
		return $this->Tipo;
	}

	public function setTipo($Tipo){
		$this->Tipo = $Tipo;
	}

	
	public function getEsVisible(){
		return $this->EsVisible;
	}

	public function setEsVisible($EsVisible){
		$this->EsVisible = $EsVisible;
	}

	
	public function getValorDefault(){
		return $this->ValorDefault;
	}

	public function setValorDefault($ValorDefault){
		$this->ValorDefault = $ValorDefault;
	}

	
	public function getEntidad(){
		return $this->Entidad;
	}

	public function setEntidad($Entidad){
		$this->Entidad = $Entidad;
	}

	
	public function getFechaCreacion(){
		return $this->FechaCreacion;
	}

	public function setFechaCreacion($FechaCreacion){
		$this->FechaCreacion = $FechaCreacion;
	}

	
	public function getFechaUltimaModificacion(){
		return $this->FechaUltimaModificacion;
	}

	public function setFechaUltimaModificacion($FechaUltimaModificacion){
		$this->FechaUltimaModificacion = $FechaUltimaModificacion;
	}

	
	public function getRelacionEntidad(){
		return $this->RelacionEntidad;
	}

	public function setRelacionEntidad($RelacionEntidad){
		$this->RelacionEntidad = $RelacionEntidad;
	}

	
	public function getRelacionEntidadCampo(){
		return $this->RelacionEntidadCampo;
	}

	public function setRelacionEntidadCampo($RelacionEntidadCampo){
		$this->RelacionEntidadCampo = $RelacionEntidadCampo;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".Campo (
			Nombre, 
			Longitud, 
			EsNull, 
			Tipo, 
			EsVisible, 
			ValorDefault, 
			Entidad, 
			RelacionEntidad, 
			RelacionEntidadCampo) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array(
				$this->Nombre, 
				$this->Longitud, 
				$this->EsNull, 
				$this->Tipo, 
				$this->EsVisible, 
				$this->ValorDefault, 
				$this->Entidad, 
				$this->RelacionEntidad, 
				$this->RelacionEntidadCampo));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$Campos = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Campo";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$Campo = new CampoModel();
			$Campo->setId($row["id"]);
			$Campo->setNombre($row["Nombre"]);
			$Campo->setLongitud($row["Longitud"]);
			$Campo->setEsNull($row["EsNull"]);
			$Campo->setTipo($row["Tipo"]);
			$Campo->setEsVisible($row["EsVisible"]);
			$Campo->setValorDefault($row["ValorDefault"]);
			$Campo->setEntidad($row["Entidad"]);
			$Campo->setFechaCreacion($row["FechaCreacion"]);
			$Campo->setFechaUltimaModificacion($row["FechaUltimaModificacion"]);
			$Campo->setRelacionEntidad($row["RelacionEntidad"]);
			$Campo->setRelacionEntidadCampo($row["RelacionEntidadCampo"]);
		  	array_push ($Campos, $Campo);
		}
		Database::disconnect();
		return $Campos;
	}

	function read($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Campo WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$Campo = new CampoModel();
		$Campo->setId($row["id"]);
		$Campo->setNombre($row["Nombre"]);
		$Campo->setLongitud($row["Longitud"]);
		$Campo->setEsNull($row["EsNull"]);
		$Campo->setTipo($row["Tipo"]);
		$Campo->setEsVisible($row["EsVisible"]);
		$Campo->setValorDefault($row["ValorDefault"]);
		$Campo->setEntidad($row["Entidad"]);
		$Campo->setFechaCreacion($row["FechaCreacion"]);
		$Campo->setFechaUltimaModificacion($row["FechaUltimaModificacion"]);
		$Campo->setRelacionEntidad($row["RelacionEntidad"]);
		$Campo->setRelacionEntidadCampo($row["RelacionEntidadCampo"]);
		return $Campo;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".Campo WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".Campo SET Nombre=?, Longitud=?, EsNull=?, Tipo=?, EsVisible=?, ValorDefault=?, Entidad=?, RelacionEntidad=?, RelacionEntidadCampo=? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->RelacionEntidadCampo, $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
