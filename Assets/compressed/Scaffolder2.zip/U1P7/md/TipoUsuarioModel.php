<?php
include_once "database.php";

Class TipoUsuarioModel {

	private $id;
	private $Nombre;
	private $Descripci�n;
	private	$db;

	function __construct (){

	  	$this->db="scaffolder2";
    	
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getId(){
		return $this->id;
	}

	
	public function getNombre(){
		return $this->Nombre;
	}

	public function setNombre($Nombre){
		$this->Nombre = $Nombre;
	}

	
	public function getDescripci�n(){
		return $this->Descripci�n;
	}

	public function setDescripci�n($Descripci�n){
		$this->Descripci�n = $Descripci�n;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".TipoUsuario (
			Nombre, 
			Descripci�n) values (?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array(
				$this->Nombre, 
				$this->Descripci�n));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$TipoUsuarios = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".TipoUsuario";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$TipoUsuario = new TipoUsuarioModel();
			$TipoUsuario->setId($row["id"]);
			$TipoUsuario->setNombre($row["Nombre"]);
			$TipoUsuario->setDescripci�n($row["Descripci�n"]);
		  	array_push ($TipoUsuarios, $TipoUsuario);
		}
		Database::disconnect();
		return $TipoUsuarios;
	}

	function read($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".TipoUsuario WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$TipoUsuario = new TipoUsuarioModel();
		$TipoUsuario->setId($row["id"]);
		$TipoUsuario->setNombre($row["Nombre"]);
		$TipoUsuario->setDescripci�n($row["Descripci�n"]);
		return $TipoUsuario;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".TipoUsuario WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".TipoUsuario SET Nombre=?, Descripci�n=? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->Descripci�n, $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
