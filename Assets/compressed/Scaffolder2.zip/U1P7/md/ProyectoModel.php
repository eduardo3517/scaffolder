<?php
include_once "database.php";

Class ProyectoModel {

	private $id;
	private $Nombre;
	private $FechaCreacion;
	private $NombreServidor;
	private $NombreBaseDatos;
	private $UsuarioBaseDatos;
	private $Contrasena;
	private $FechaUltimaModificacion;
	private $Usuario;
	private	$db;

	function __construct (){

	  	$this->db="scaffolder2";
    	
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getId(){
		return $this->id;
	}

	
	public function getNombre(){
		return $this->Nombre;
	}

	public function setNombre($Nombre){
		$this->Nombre = $Nombre;
	}

	
	public function getFechaCreacion(){
		return $this->FechaCreacion;
	}

	public function setFechaCreacion($FechaCreacion){
		$this->FechaCreacion = $FechaCreacion;
	}

	
	public function getNombreServidor(){
		return $this->NombreServidor;
	}

	public function setNombreServidor($NombreServidor){
		$this->NombreServidor = $NombreServidor;
	}

	
	public function getNombreBaseDatos(){
		return $this->NombreBaseDatos;
	}

	public function setNombreBaseDatos($NombreBaseDatos){
		$this->NombreBaseDatos = $NombreBaseDatos;
	}

	
	public function getUsuarioBaseDatos(){
		return $this->UsuarioBaseDatos;
	}

	public function setUsuarioBaseDatos($UsuarioBaseDatos){
		$this->UsuarioBaseDatos = $UsuarioBaseDatos;
	}

	
	public function getContrasena(){
		return $this->Contrasena;
	}

	public function setContrasena($Contrasena){
		$this->Contrasena = $Contrasena;
	}

	
	public function getFechaUltimaModificacion(){
		return $this->FechaUltimaModificacion;
	}

	public function setFechaUltimaModificacion($FechaUltimaModificacion){
		$this->FechaUltimaModificacion = $FechaUltimaModificacion;
	}

	
	public function getUsuario(){
		return $this->Usuario;
	}

	public function setUsuario($Usuario){
		$this->Usuario = $Usuario;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".Proyecto (
			Nombre, 
			NombreServidor, 
			NombreBaseDatos, 
			UsuarioBaseDatos, 
			Contrasena, 
			Usuario) values (?, ?, ?, ?, ?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array(
				$this->Nombre, 
				$this->NombreServidor, 
				$this->NombreBaseDatos, 
				$this->UsuarioBaseDatos, 
				$this->Contrasena, 
				$this->Usuario));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$Proyectos = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Proyecto";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$Proyecto = new ProyectoModel();
			$Proyecto->setId($row["id"]);
			$Proyecto->setNombre($row["Nombre"]);
			$Proyecto->setFechaCreacion($row["FechaCreacion"]);
			$Proyecto->setNombreServidor($row["NombreServidor"]);
			$Proyecto->setNombreBaseDatos($row["NombreBaseDatos"]);
			$Proyecto->setUsuarioBaseDatos($row["UsuarioBaseDatos"]);
			$Proyecto->setContrasena($row["Contrasena"]);
			$Proyecto->setFechaUltimaModificacion($row["FechaUltimaModificacion"]);
			$Proyecto->setUsuario($row["Usuario"]);
		  	array_push ($Proyectos, $Proyecto);
		}
		Database::disconnect();
		return $Proyectos;
	}

	function read($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Proyecto WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$Proyecto = new ProyectoModel();
		$Proyecto->setId($row["id"]);
		$Proyecto->setNombre($row["Nombre"]);
		$Proyecto->setFechaCreacion($row["FechaCreacion"]);
		$Proyecto->setNombreServidor($row["NombreServidor"]);
		$Proyecto->setNombreBaseDatos($row["NombreBaseDatos"]);
		$Proyecto->setUsuarioBaseDatos($row["UsuarioBaseDatos"]);
		$Proyecto->setContrasena($row["Contrasena"]);
		$Proyecto->setFechaUltimaModificacion($row["FechaUltimaModificacion"]);
		$Proyecto->setUsuario($row["Usuario"]);
		return $Proyecto;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".Proyecto WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".Proyecto SET Nombre=?, NombreServidor=?, NombreBaseDatos=?, UsuarioBaseDatos=?, Contrasena=?, Usuario=? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->Usuario, $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
