<?php
include_once "database.php";

Class EntidadModel {

	private $id;
	private $Nombre;
	private $Proyecto;
	private $TieneSeguridadUsuario;
	private $FechaCreacion;
	private $FechaUltimaModificacion;
	private $Comentario;
	private $Relacion;
	private	$db;

	function __construct (){

	  	$this->db="scaffolder2";
    	
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getId(){
		return $this->id;
	}

	
	public function getNombre(){
		return $this->Nombre;
	}

	public function setNombre($Nombre){
		$this->Nombre = $Nombre;
	}

	
	public function getProyecto(){
		return $this->Proyecto;
	}

	public function setProyecto($Proyecto){
		$this->Proyecto = $Proyecto;
	}

	
	public function getTieneSeguridadUsuario(){
		return $this->TieneSeguridadUsuario;
	}

	public function setTieneSeguridadUsuario($TieneSeguridadUsuario){
		$this->TieneSeguridadUsuario = $TieneSeguridadUsuario;
	}

	
	public function getFechaCreacion(){
		return $this->FechaCreacion;
	}

	public function setFechaCreacion($FechaCreacion){
		$this->FechaCreacion = $FechaCreacion;
	}

	
	public function getFechaUltimaModificacion(){
		return $this->FechaUltimaModificacion;
	}

	public function setFechaUltimaModificacion($FechaUltimaModificacion){
		$this->FechaUltimaModificacion = $FechaUltimaModificacion;
	}

	
	public function getComentario(){
		return $this->Comentario;
	}

	public function setComentario($Comentario){
		$this->Comentario = $Comentario;
	}

	
	public function getRelacion(){
		return $this->Relacion;
	}

	public function setRelacion($Relacion){
		$this->Relacion = $Relacion;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".Entidad (
			Nombre, 
			Proyecto, 
			TieneSeguridadUsuario, 
			Comentario, 
			Relacion) values (?, ?, ?, ?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array(
				$this->Nombre, 
				$this->Proyecto, 
				$this->TieneSeguridadUsuario, 
				$this->Comentario, 
				$this->Relacion));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$Entidads = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Entidad";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$Entidad = new EntidadModel();
			$Entidad->setId($row["id"]);
			$Entidad->setNombre($row["Nombre"]);
			$Entidad->setProyecto($row["Proyecto"]);
			$Entidad->setTieneSeguridadUsuario($row["TieneSeguridadUsuario"]);
			$Entidad->setFechaCreacion($row["FechaCreacion"]);
			$Entidad->setFechaUltimaModificacion($row["FechaUltimaModificacion"]);
			$Entidad->setComentario($row["Comentario"]);
			$Entidad->setRelacion($row["Relacion"]);
		  	array_push ($Entidads, $Entidad);
		}
		Database::disconnect();
		return $Entidads;
	}

	function read($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Entidad WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$Entidad = new EntidadModel();
		$Entidad->setId($row["id"]);
		$Entidad->setNombre($row["Nombre"]);
		$Entidad->setProyecto($row["Proyecto"]);
		$Entidad->setTieneSeguridadUsuario($row["TieneSeguridadUsuario"]);
		$Entidad->setFechaCreacion($row["FechaCreacion"]);
		$Entidad->setFechaUltimaModificacion($row["FechaUltimaModificacion"]);
		$Entidad->setComentario($row["Comentario"]);
		$Entidad->setRelacion($row["Relacion"]);
		return $Entidad;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".Entidad WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".Entidad SET Nombre=?, Proyecto=?, TieneSeguridadUsuario=?, Comentario=?, Relacion=? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->Relacion, $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
