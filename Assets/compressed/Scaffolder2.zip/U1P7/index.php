<?php 

header ("location: ct/SeguridadController.php?c=lgv");

?>
	
