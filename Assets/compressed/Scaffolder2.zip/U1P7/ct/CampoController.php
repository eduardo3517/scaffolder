<?php
  
include '../md/CampoModel.php';
include '../md/UsuarioModel.php';
include_once '../util/Messages.php';

class CampoController{
    
	private $CampoModel;
	private const SESSION_TAG = "IDUSUARIOSISTEMAU1P7";
    
	public function __CONSTRUCT(){
		$this->CampoModel = new CampoModel();
		if(!isset($_SESSION)) { 
			session_start();
		}
	}

	public function direccionar($c, $mensaje){
		if(!isset($_SESSION[$this::SESSION_TAG])){
			require_once "../vw/Templates/header.php";
			require_once "../vw/login.php";
			require_once "../vw/Templates/footer.php";
		} else {
			$UsuarioModel = new UsuarioModel();
			$UsuarioLogueado = $UsuarioModel->read($_SESSION[$this::SESSION_TAG]);
			$Permiso = $UsuarioModel->getPermissions($_SESSION[$this::SESSION_TAG], 8);

			if ($Permiso==-1){
				require_once "../vw/Templates/header.php";
				require_once "../vw/PaginaError.php";
				require_once "../vw/Templates/footer.php";
				
			} else {

				switch ($c){
					case "c":
						require_once "../vw/Campo/create.php";
					break;

					case "i":
						
						{
							if (in_array(5, $Permiso)){
							
								require_once "../vw/Campo/index.php";
							}
						}
					break;

					case "r":
						require_once "../vw/Campo/read.php";
					break;

					case "d":
						require_once "../vw/Campo/delete.php";
					break;

					case "u":
						require_once "../vw/Campo/update.php";
					break;

					case "b":
						$this->delete();
					break;

					case "g":
						$this->create();
					break;

					case "a":
						$this->update();
					break;

					default:
						header ("location: ../index.php");
					break;
					
				} 
			}
		}
	}
	
    
	public function list(){

        return $this->CampoModel->list();
        
	}

	public function read($id){

        return $this->CampoModel->read($id);
        
	}


	public function create(){
      
		
		$Campo = new CampoModel();
		$Campo->setNombre(trim($_REQUEST["Nombre"]));
		$Campo->setLongitud(trim($_REQUEST["Longitud"]));
		$Campo->setEsNull(trim($_REQUEST["EsNull"]));
		$Campo->setTipo(trim($_REQUEST["Tipo"]));
		$Campo->setEsVisible(trim($_REQUEST["EsVisible"]));
		$Campo->setValorDefault(trim($_REQUEST["ValorDefault"]));
		$Campo->setEntidad(trim($_REQUEST["Entidad"]));
		$Campo->setRelacionEntidad(trim($_REQUEST["RelacionEntidad"]));
		$Campo->setRelacionEntidadCampo(trim($_REQUEST["RelacionEntidadCampo"]));
		$message = $Campo->create(); 
		if ($message==23000){
			$this->direccionar("i",  Messages::DUPLICATED_CREATE_ERROR);
		} else if ($message != ""){
			$this->direccionar("i", Messages::GENERIC_ERROR.$message);
		} else {
			
			$this->direccionar("i", Messages::CREATE_SUCCESS);
		}
		
	}
                                    
	public function update(){

		$Campo = new CampoModel();
		$Campo->setId(trim($_REQUEST["id"]));
		$Campo->setNombre(trim($_REQUEST["Nombre"]));
		$Campo->setLongitud(trim($_REQUEST["Longitud"]));
		$Campo->setEsNull(trim($_REQUEST["EsNull"]));
		$Campo->setTipo(trim($_REQUEST["Tipo"]));
		$Campo->setEsVisible(trim($_REQUEST["EsVisible"]));
		$Campo->setValorDefault(trim($_REQUEST["ValorDefault"]));
		$Campo->setEntidad(trim($_REQUEST["Entidad"]));
		$Campo->setRelacionEntidad(trim($_REQUEST["RelacionEntidad"]));
		$Campo->setRelacionEntidadCampo(trim($_REQUEST["RelacionEntidadCampo"]));
		$message = $Campo->update(); //realiza la operación de actualizado
		if ($message==23000){
			$this->direccionar("i", Messages::DUPLICATED_UPDATE_ERROR);
		} else if($message != ""){
			$this->direccionar("i", Messages::GENERIC_ERROR.$message);
		} else {
			$this->direccionar("i", Messages::UPDATE_SUCCESS);
		}
	}
    
	public function delete(){
		$id = trim($_REQUEST["id"]);
		$message = $this->CampoModel->delete($id);
		if ($message==23000){
			$this->direccionar("i", Messages::RELATED_REG_DELETE_ERROR);
		} else if ($message!=""){
			$this->direccionar("i", Messages::GENERIC_ERROR.$message);
		} else {
			$this->direccionar("i", Messages::DELETE_SUCCESS);
		}
	}

	
}
 
$controladorCampo = new CampoController();
$c="";
if(isset($_POST["c"])){
	$c=$_POST["c"];
} else {
	$c="i";
}
$controladorCampo->direccionar($c, "");

?>
