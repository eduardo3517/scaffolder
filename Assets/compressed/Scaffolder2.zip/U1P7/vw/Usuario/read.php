
	<?php
		$Usuario = $this->read($_POST['id']);
	?>
	<div class="modal-header">
		<h5 class="modal-title" id="exampleModalLongTitle">Detalle de Usuario</h5>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>

	<div class="modal-body">
		<div class="col-sm-10 offset-md-1">
			<div class="card border-light">
				<div class="card-header">Nombre</div>
				<div class="card-body">
					<p class="card-text">
						<img class="img-fluid" src="UsuarioController.php?Nombre_id=<?php echo $Usuario->getId();?>" alt="UsuarioNombre"/>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Apellido</div>
				<div class="card-body">
					<p class="card-text">
						<img class="img-fluid" src="UsuarioController.php?Apellido_id=<?php echo $Usuario->getId();?>" alt="UsuarioApellido"/>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">CorreoElectronico</div>
				<div class="card-body">
					<p class="card-text">
						<img class="img-fluid" src="UsuarioController.php?CorreoElectronico_id=<?php echo $Usuario->getId();?>" alt="UsuarioCorreoElectronico"/>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Contrasena</div>
				<div class="card-body">
					<p class="card-text">
						<img class="img-fluid" src="UsuarioController.php?Contrasena_id=<?php echo $Usuario->getId();?>" alt="UsuarioContrasena"/>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">TipoUsuario</div>
				<div class="card-body">
					<p class="card-text"> 
					<?php
						include_once '../md/SeguridadModel.php';
						$Seguridad = new SeguridadModel();
						$Encontrado = $Seguridad->read($Usuario->getTipoUsuario());
						echo $Encontrado->getNombre();
					?>
					</p>
				</div>
			</div>
		</div> 
	</div> 
	<div class="modal-footer">
		<button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Atrás</button>
	</div>
