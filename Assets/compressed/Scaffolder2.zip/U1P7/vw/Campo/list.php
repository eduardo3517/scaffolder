

		<h3 class="display-6" id="tableDesc">Listado de Campo</h3>
	   	<br>
	   
	   	<table id="dtCampo" class="table table-striped table-bordered table-sm" aria-describedby="tableDesc">
		   
		   	<thead class="thead-light">
			   	<tr>
					<th scope="col" style="width:8.3333333333333%">
						Nombre
					</th>
					<th scope="col" style="width:8.3333333333333%">
						Longitud
					</th>
					<th scope="col" style="width:8.3333333333333%">
						EsNull
					</th>
					<th scope="col" style="width:8.3333333333333%">
						Tipo
					</th>
					<th scope="col" style="width:8.3333333333333%">
						EsVisible
					</th>
					<th scope="col" style="width:8.3333333333333%">
						ValorDefault
					</th>
					<th scope="col" style="width:8.3333333333333%">
						Entidad
					</th>
					<th scope="col" style="width:8.3333333333333%">
						RelacionEntidad
					</th>
					<th scope="col" style="width:8.3333333333333%">
						RelacionEntidadCampo
					</th>
				   <th scope="col" style="width:8.3333333333333%">
					   Acciones
				   </th>
			   </tr>
		   </thead>
		   <tbody>
		   <?php
			   	$Campos = $this->list();
			   	foreach ($Campos as $row) {

					$readButton = in_array(1, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'r\', \'Campo\')" ><i class="material-icons">remove_red_eye</i></button>':''; 
					$updateButton = in_array(4, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'u\', \'Campo\')" ><i class="material-icons">create</i></button>':''; 
					$deleteButton = in_array(3, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-danger btn-sm" onclick="accionModal(\''.$row->getId().'\', \'d\', \'Campo\')" ><i class="material-icons">delete</i></button>':''; 
					
					include_once '../md/EntidadModel.php';
					$Entidad = new EntidadModel();
					$Encontrado = $Entidad->read($row->getEntidad());
				
				include_once '../md/EntidadModel.php';
					$Entidad = new EntidadModel();
					$Encontrado = $Entidad->read($row->getRelacionEntidad());
				
				include_once '../md/CampoModel.php';
					$Campo = new CampoModel();
					$Encontrado = $Campo->read($row->getRelacionEntidadCampo());
				
				

					echo '
					<tr>
						<td scope="col" style="width:8.3333333333333%">
							'. $row->getNombre() . '
						</td>
						
						<td scope="col" style="width:8.3333333333333%">
							'. $row->getLongitud() . '
						</td>
						
						<td scope="col" style="width:8.3333333333333%">
							'. $row->getEsNull() . '
						</td>
						
						<td scope="col" style="width:8.3333333333333%">
							'. $row->getTipo() . '
						</td>
						
						<td scope="col" style="width:8.3333333333333%">
							'. $row->getEsVisible() . '
						</td>
						
						<td scope="col" style="width:8.3333333333333%">
							'. $row->getValorDefault() . '
						</td>
						
						<td scope="col" style="width:8.3333333333333%">
							<a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Entidad\')" >
								'.$Encontrado->getNombre() .'
							</a>
						</td>
						
						<td scope="col" style="width:8.3333333333333%">
							<a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Entidad\')" >
								'.$Encontrado->getNombre() .'
							</a>
						</td>
						
						<td scope="col" style="width:8.3333333333333%">
							<a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Campo\')" >
								'.$Encontrado->getNombre() .'
							</a>
						</td>
						
						<td scope="col" style="width:8.3333333333333%">
							<div class="btn-group" role="group" aria-label="Basic example">
								'.$readButton.'
								'.$updateButton.' 
								'.$deleteButton.'
				   			</div>
					   </td>
				   </tr>';
			   }
		   ?>
		   </tbody>
	   </table>
	   
   
