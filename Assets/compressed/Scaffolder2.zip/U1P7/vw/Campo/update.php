
	<?php
		$Campo = $this->read($_POST['id']);
	?>
	<form action="CampoController.php" method="post" enctype="multipart/form-data">
		<div class="modal-header">
			<h5 class="modal-title" id="exampleModalLongTitle">Modificar Campo</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
		<div class="modal-body">
			<div class = "row">
				<div class ="col">
				</div>
				<div class ="col-10">
					<h4 class="display-12">Llena todos los campos requeridos.</h4>
					<br>
					<input class="form-control" name="c" type="hidden" value="a" >
					<input class="form-control" name="id" type="hidden" value="<?php echo $Campo->getId();?>" >
						<label for="Nombre">Nombre</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="Nombre" type="Cadena" title="Este campo es sólo números o letras." <?php echo 'value="'.$Campo->getNombre().'"'?>  required>
							</div>
						</div>
						<label for="Longitud">Longitud</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="Longitud" type="Cadena" title="Este campo es sólo números o letras." <?php echo 'value="'.$Campo->getLongitud().'"'?>  required>
							</div>
						</div>
						<label for="EsNull">EsNull</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="EsNull" type="Numérico" title="Este campo es sólo números." <?php echo 'value="'.$Campo->getEsNull().'"'?>  required>
							</div>
						</div>
						<label for="Tipo">Tipo</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="Tipo" type="Cadena" title="Este campo es sólo números o letras." <?php echo 'value="'.$Campo->getTipo().'"'?>  required>
							</div>
						</div>
						<label for="EsVisible">EsVisible</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="EsVisible" type="Numérico" title="Este campo es sólo números." <?php echo 'value="'.$Campo->getEsVisible().'"'?>  required>
							</div>
						</div>
						<label for="ValorDefault">ValorDefault</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="ValorDefault" type="Cadena" title="Este campo es sólo números o letras." <?php echo 'value="'.$Campo->getValorDefault().'"'?>  required>
							</div>
						</div>

						<label for="NumeroId">Entidad</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<select class="form-control" name="Entidad" required>
									<?php
										include "../md/EntidadModel.php";
										$Entidad = new EntidadModel();
										$Entidads = $Entidad->list();

										foreach ($Entidads as $Fila){
											$selected = $Campo->getEntidad()==$Fila->getId()?'" selected="selected">':'" >';
											echo '<option value="'.$Fila->getId().$selected.$Fila->getNombre().'</option>';
										}
									?>
								</select>
							</div>
						</div>

						<label for="NumeroId">RelacionEntidad</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<select class="form-control" name="RelacionEntidad" required>
									<?php
										include "../md/EntidadModel.php";
										$Entidad = new EntidadModel();
										$Entidads = $Entidad->list();

										foreach ($Entidads as $Fila){
											$selected = $Campo->getRelacionEntidad()==$Fila->getId()?'" selected="selected">':'" >';
											echo '<option value="'.$Fila->getId().$selected.$Fila->getNombre().'</option>';
										}
									?>
								</select>
							</div>
						</div>

						<label for="NumeroId">RelacionEntidadCampo</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<select class="form-control" name="RelacionEntidadCampo" required>
									<?php
										include "../md/CampoModel.php";
										$Campo = new CampoModel();
										$Campos = $Campo->list();

										foreach ($Campos as $Fila){
											$selected = $Campo->getRelacionEntidadCampo()==$Fila->getId()?'" selected="selected">':'" >';
											echo '<option value="'.$Fila->getId().$selected.$Fila->getNombre().'</option>';
										}
									?>
								</select>
							</div>
						</div>
				</div>
				<div class ="col">
				</div>
			</div>
		</div>
		<div class="modal-footer">
			<button type="submit" class="btn btn-outline-primary btn-sm">Actualizar</button>
			<button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Cancelar</button>
		</div>
	</form>

