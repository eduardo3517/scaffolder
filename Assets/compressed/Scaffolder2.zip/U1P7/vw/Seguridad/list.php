

		<h3 class="display-6" id="tableDesc">Listado de Seguridad</h3>
	   	<br>
	   
	   	<table id="dtSeguridad" class="table table-striped table-bordered table-sm" aria-describedby="tableDesc">
		   
		   	<thead class="thead-light">
			   	<tr>
					<th scope="col" style="width:25%">
						TipoUsuario
					</th>
					<th scope="col" style="width:25%">
						EntidadSeguridad
					</th>
					<th scope="col" style="width:25%">
						AccionSeguridad
					</th>
				   <th scope="col" style="width:25%">
					   Acciones
				   </th>
			   </tr>
		   </thead>
		   <tbody>
		   <?php
			   	$Seguridads = $this->list();
			   	foreach ($Seguridads as $row) {

					$readButton = in_array(1, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'r\', \'Seguridad\')" ><i class="material-icons">remove_red_eye</i></button>':''; 
					$updateButton = in_array(4, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'u\', \'Seguridad\')" ><i class="material-icons">create</i></button>':''; 
					$deleteButton = in_array(3, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-danger btn-sm" onclick="accionModal(\''.$row->getId().'\', \'d\', \'Seguridad\')" ><i class="material-icons">delete</i></button>':''; 
					
					include_once '../md/TipoUsuarioModel.php';
					$TipoUsuario = new TipoUsuarioModel();
					$Encontrado = $TipoUsuario->read($row->getTipoUsuario());
				
				include_once '../md/EntidadSeguridadModel.php';
					$EntidadSeguridad = new EntidadSeguridadModel();
					$Encontrado = $EntidadSeguridad->read($row->getEntidadSeguridad());
				
				include_once '../md/AccionSeguridadModel.php';
					$AccionSeguridad = new AccionSeguridadModel();
					$Encontrado = $AccionSeguridad->read($row->getAccionSeguridad());
				
				

					echo '
					<tr>
						<td scope="col" style="width:25%">
							<a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'TipoUsuario\')" >
								'.$Encontrado->getNombre() .'
							</a>
						</td>
						
						<td scope="col" style="width:25%">
							<a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'EntidadSeguridad\')" >
								'.$Encontrado->getNombre() .'
							</a>
						</td>
						
						<td scope="col" style="width:25%">
							<a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'AccionSeguridad\')" >
								'.$Encontrado->getNombre() .'
							</a>
						</td>
						
						<td scope="col" style="width:25%">
							<div class="btn-group" role="group" aria-label="Basic example">
								'.$readButton.'
								'.$updateButton.' 
								'.$deleteButton.'
				   			</div>
					   </td>
				   </tr>';
			   }
		   ?>
		   </tbody>
	   </table>
	   
   
