

		<h3 class="display-6" id="tableDesc">Listado de Entidad</h3>
	   	<br>
	   
	   	<table id="dtEntidad" class="table table-striped table-bordered table-sm" aria-describedby="tableDesc">
		   
		   	<thead class="thead-light">
			   	<tr>
					<th scope="col" style="width:12.5%">
						Nombre
					</th>
					<th scope="col" style="width:12.5%">
						Proyecto
					</th>
					<th scope="col" style="width:12.5%">
						TieneSeguridadUsuario
					</th>
					<th scope="col" style="width:12.5%">
						Comentario
					</th>
					<th scope="col" style="width:12.5%">
						Relacion
					</th>
				   <th scope="col" style="width:12.5%">
					   Acciones
				   </th>
			   </tr>
		   </thead>
		   <tbody>
		   <?php
			   	$Entidads = $this->list();
			   	foreach ($Entidads as $row) {

					$readButton = in_array(1, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'r\', \'Entidad\')" ><i class="material-icons">remove_red_eye</i></button>':''; 
					$updateButton = in_array(4, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'u\', \'Entidad\')" ><i class="material-icons">create</i></button>':''; 
					$deleteButton = in_array(3, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-danger btn-sm" onclick="accionModal(\''.$row->getId().'\', \'d\', \'Entidad\')" ><i class="material-icons">delete</i></button>':''; 
					
					include_once '../md/ProyectoModel.php';
					$Proyecto = new ProyectoModel();
					$Encontrado = $Proyecto->read($row->getProyecto());
				
				include_once '../md/EntidadModel.php';
					$Entidad = new EntidadModel();
					$Encontrado = $Entidad->read($row->getRelacion());
				
				

					echo '
					<tr>
						<td scope="col" style="width:12.5%">
							'. $row->getNombre() . '
						</td>
						
						<td scope="col" style="width:12.5%">
							<a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Proyecto\')" >
								'.$Encontrado->getNombre() .'
							</a>
						</td>
						
						<td scope="col" style="width:12.5%">
							'. $row->getTieneSeguridadUsuario() . '
						</td>
						
						<td scope="col" style="width:12.5%">
							'. $row->getComentario() . '
						</td>
						
						<td scope="col" style="width:12.5%">
							<a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Entidad\')" >
								'.$Encontrado->getNombre() .'
							</a>
						</td>
						
						<td scope="col" style="width:12.5%">
							<div class="btn-group" role="group" aria-label="Basic example">
								'.$readButton.'
								'.$updateButton.' 
								'.$deleteButton.'
				   			</div>
					   </td>
				   </tr>';
			   }
		   ?>
		   </tbody>
	   </table>
	   
   
