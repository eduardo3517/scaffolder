

		<h3 class="display-6" id="tableDesc">Listado de Proyecto</h3>
	   	<br>
	   
	   	<table id="dtProyecto" class="table table-striped table-bordered table-sm" aria-describedby="tableDesc">
		   
		   	<thead class="thead-light">
			   	<tr>
					<th scope="col" style="width:11.111111111111%">
						Nombre
					</th>
					<th scope="col" style="width:11.111111111111%">
						NombreServidor
					</th>
					<th scope="col" style="width:11.111111111111%">
						NombreBaseDatos
					</th>
					<th scope="col" style="width:11.111111111111%">
						UsuarioBaseDatos
					</th>
					<th scope="col" style="width:11.111111111111%">
						Contrasena
					</th>
				   <th scope="col" style="width:11.111111111111%">
					   Acciones
				   </th>
			   </tr>
		   </thead>
		   <tbody>
		   <?php
			   	$Proyectos = $this->list();
			   	foreach ($Proyectos as $row) {

					$readButton = in_array(1, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'r\', \'Proyecto\')" ><i class="material-icons">remove_red_eye</i></button>':''; 
					$updateButton = in_array(4, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'u\', \'Proyecto\')" ><i class="material-icons">create</i></button>':''; 
					$deleteButton = in_array(3, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-danger btn-sm" onclick="accionModal(\''.$row->getId().'\', \'d\', \'Proyecto\')" ><i class="material-icons">delete</i></button>':''; 
					
					

					echo '
					<tr>
						<td scope="col" style="width:11.111111111111%">
							'. $row->getNombre() . '
						</td>
						
						<td scope="col" style="width:11.111111111111%">
							'. $row->getNombreServidor() . '
						</td>
						
						<td scope="col" style="width:11.111111111111%">
							'. $row->getNombreBaseDatos() . '
						</td>
						
						<td scope="col" style="width:11.111111111111%">
							'. $row->getUsuarioBaseDatos() . '
						</td>
						
						<td scope="col" style="width:11.111111111111%">
							'. $row->getContrasena() . '
						</td>
						
						<td scope="col" style="width:11.111111111111%">
							<div class="btn-group" role="group" aria-label="Basic example">
								'.$readButton.'
								'.$updateButton.' 
								'.$deleteButton.'
				   			</div>
					   </td>
				   </tr>';
			   }
		   ?>
		   </tbody>
	   </table>
	   
   
