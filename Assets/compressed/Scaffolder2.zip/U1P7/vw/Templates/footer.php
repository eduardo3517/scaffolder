        <section once="" class="cid-ry0t7pWmqw" id="footer6-5">
            <div class="container">
                <div class="media-container-row align-center mbr-white">
                    <div class="col-12">
                        <p class="mbr-text mb-0 mbr-fonts-style display-7">
                            © Copyright - All Rights Reserved
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Modal -->
		
		<div class="modal fade bd-example-modal-lg" id="modal" tabindex="-1" role="dialog" aria-labelledby="ModalAcciones" aria-hidden="true">
		  	<div class="modal-dialog modal-lg" role="document">
			    <div class="modal-content" id="modalContent">

			    </div>
		  	</div>
        </div>
        
        <script src="../assets/web/assets/jquery/jquery.min.js"></script>
        <script src="../assets/popper/popper.min.js"></script>
        <script src="../assets/tether/tether.min.js"></script>
        <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="../assets/touchswipe/jquery.touch-swipe.min.js"></script>
        <script src="../assets/parallax/jarallax.min.js"></script>
        <script src="../assets/vimeoplayer/jquery.mb.vimeo_player.js"></script>
        <script src="../assets/smoothscroll/smooth-scroll.js"></script>
        <script src="../assets/dropdown/js/script.min.js"></script>
        <script src="../assets/theme/js/script.js"></script>
        <script src="../assets/datatable/js/addons/datatables.min.js"></script>
        <script src="../assets/js/propio.js"></script>
        <script src="../assets/js/datatable.js"></script>
    
    </body>
</html>