
	
		<div class="container">
			<div class="row">
				<div class="col-3">
				</div>

				<div class="col-6">
					<img src="../assets/images/not_authorized.jpg" class="img-fluid" alt="No está autorizado para acceder a esta pantalla.">
					<br>
					<br>
					<br>
					<br>
					<h3 class="text-justify">Sin permisos para esta Información</h3>
					
				</div>

				<div class="col-3">
				</div>
			</div>
		</div>
	