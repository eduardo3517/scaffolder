
	<?php
		$Asamblea = $this->read($_POST['id']);
	?>
	<form action="AsambleaController.php" method="post" enctype="multipart/form-data">
		<div class="modal-header">
			<h5 class="modal-title" id="exampleModalLongTitle">Modificar Asamblea</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
		<div class="modal-body">
			<div class = "row">
				<div class ="col">
				</div>
				<div class ="col-10">
					<h4 class="display-12">Llena todos los campos requeridos.</h4>
					<br>
					<input class="form-control" name="c" type="hidden" value="a" >
					<input class="form-control" name="id" type="hidden" value="<?php echo $Asamblea->getId();?>" >
						<label for="Nombre">Nombre</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="Nombre" type="Cadena" title="Este campo es sólo números o letras." <?php echo 'value="'.$Asamblea->getNombre().'"'?>  required>
							</div>
						</div>
						<label for="Fecha">Fecha</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="Fecha" type="Fecha" title="Este campo es sólo tipo fecha." <?php echo 'value="'.$Asamblea->getFecha().'"'?>  required>
							</div>
						</div>
						<label for="Contrasena">Contrasena</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="Contrasena" type="Contraseña" title="Este campo es de tipo contraseña." <?php echo 'value="'.$Asamblea->getContrasena().'"'?>  required>
							</div>
						</div>
						<label for="Cantidad">Cantidad</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="Cantidad" type="Numérico" title="Este campo es sólo números." <?php echo 'value="'.$Asamblea->getCantidad().'"'?>  required>
							</div>
						</div>
						<label for="CorreoElectronico">CorreoElectronico</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="CorreoElectronico" type="Correo" title="Este campo es sólo tipo correo electrónico." <?php echo 'value="'.$Asamblea->getCorreoElectronico().'"'?>  required>
							</div>
						</div>
						<label for="Hora">Hora</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="Hora" type="Hora" title="Este campo es sólo tipo hora." <?php echo 'value="'.$Asamblea->getHora().'"'?>  required>
							</div>
						</div>
						<label for="HoraFecha">HoraFecha</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="HoraFecha" type="Hora Fecha" title="" <?php echo 'value="'.$Asamblea->getHoraFecha().'"'?>  required>
							</div>
						</div>

						<label for="NumeroId">TipoUsuario</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<select class="form-control" name="TipoUsuario" required>
									<?php
										include "../md/TipoUsuarioModel.php";
										$TipoUsuario = new TipoUsuarioModel();
										$TipoUsuarios = $TipoUsuario->list();

										foreach ($TipoUsuarios as $Fila){
											$selected = $Asamblea->getTipoUsuario()==$Fila->getId()?'" selected="selected">':'" >';
											echo '<option value="'.$Fila->getId().$selected.$Fila->getNombre().'</option>';
										}
									?>
								</select>
							</div>
						</div>
						<label for="Icono">Icono</label>
						<div class="form-group input-group">
							<div class="col-sm-12">
								<input class="form-control" name="Icono" type="file">
							</div>
						</div>
				</div>
				<div class ="col">
				</div>
			</div>
		</div>
		<div class="modal-footer">
			<button type="submit" class="btn btn-outline-primary btn-sm">Actualizar</button>
			<button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Cancelar</button>
		</div>
	</form>

