
	<?php
		$Asamblea = $this->read($_POST['id']);
	?>
	<div class="modal-header">
		<h5 class="modal-title" id="exampleModalLongTitle">Detalle de Asamblea</h5>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>

	<div class="modal-body">
		<div class="col-sm-10 offset-md-1">
			<div class="card border-light">
				<div class="card-header">Nombre</div>
				<div class="card-body">
					<p class="card-text">
						<?php echo $Asamblea->getNombre();?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Fecha</div>
				<div class="card-body">
					<p class="card-text">
						<?php echo $Asamblea->getFecha();?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Contrasena</div>
				<div class="card-body">
					<p class="card-text">
						<?php echo $Asamblea->getContrasena();?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Cantidad</div>
				<div class="card-body">
					<p class="card-text">
						<?php echo $Asamblea->getCantidad();?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">CorreoElectronico</div>
				<div class="card-body">
					<p class="card-text">
						<?php echo $Asamblea->getCorreoElectronico();?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Hora</div>
				<div class="card-body">
					<p class="card-text">
						<?php echo $Asamblea->getHora();?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">HoraFecha</div>
				<div class="card-body">
					<p class="card-text">
						<?php echo $Asamblea->getHoraFecha();?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">TipoUsuario</div>
				<div class="card-body">
					<p class="card-text"> 
					<?php
						include_once '../md/TipoUsuarioModel.php';
						$TipoUsuario = new TipoUsuarioModel();
						$Encontrado = $TipoUsuario->read($Asamblea->getTipoUsuario());
						echo $Encontrado->getNombre();
					?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">FechaActual</div>
				<div class="card-body">
					<p class="card-text">
						<?php echo $Asamblea->getFechaActual();?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Icono</div>
				<div class="card-body">
					<p class="card-text">
						<img class="img-fluid" src="AsambleaController.php?Icono_id=<?php echo $Asamblea->getId();?>" alt="AsambleaIcono"/>
					</p>
				</div>
			</div>
		</div> 
	</div> 
	<div class="modal-footer">
		<button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Atrás</button>
	</div>
