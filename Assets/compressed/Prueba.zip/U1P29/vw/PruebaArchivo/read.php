
	<?php
		$PruebaArchivo = $this->read($_POST['id']);
	?>
	<div class="modal-header">
		<h5 class="modal-title" id="exampleModalLongTitle">Detalle de PruebaArchivo</h5>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>

	<div class="modal-body">
		<div class="col-sm-10 offset-md-1">
			<div class="card border-light">
				<div class="card-header">Foto</div>
				<div class="card-body">
					<p class="card-text">
						<img class="img-fluid" src="PruebaArchivoController.php?Foto_id=<?php echo $PruebaArchivo->getId();?>" alt="PruebaArchivoFoto"/>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Asamblea</div>
				<div class="card-body">
					<p class="card-text"> 
					<?php
						include_once '../md/AsambleaModel.php';
						$Asamblea = new AsambleaModel();
						$Encontrado = $Asamblea->read($PruebaArchivo->getAsamblea());
						echo $Encontrado->getNombre();
					?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Icono</div>
				<div class="card-body">
					<p class="card-text">
						<img class="img-fluid" src="PruebaArchivoController.php?Icono_id=<?php echo $PruebaArchivo->getId();?>" alt="PruebaArchivoIcono"/>
					</p>
				</div>
			</div>
		</div> 
	</div> 
	<div class="modal-footer">
		<button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Atrás</button>
	</div>
