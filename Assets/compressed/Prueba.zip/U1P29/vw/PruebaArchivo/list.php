

		<h3 class="display-6" id="tableDesc">Listado de PruebaArchivo</h3>
	   	<br>
	   
	   	<table id="dtPruebaArchivo" class="table table-striped table-bordered table-sm" aria-describedby="tableDesc">
		   
		   	<thead class="thead-light">
			   	<tr>
					<th scope="col" style="width:25%">
						Foto
					</th>
					<th scope="col" style="width:25%">
						Asamblea
					</th>
					<th scope="col" style="width:25%">
						Icono
					</th>
				   <th scope="col" style="width:25%">
					   Acciones
				   </th>
			   </tr>
		   </thead>
		   <tbody>
		   <?php
			   	$PruebaArchivos = $this->list();
			   	foreach ($PruebaArchivos as $row) {

					$readButton = in_array(1, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'r\', \'PruebaArchivo\')" ><i class="material-icons">remove_red_eye</i></button>':''; 
					$updateButton = in_array(4, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'u\', \'PruebaArchivo\')" ><i class="material-icons">create</i></button>':''; 
					$deleteButton = in_array(3, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-danger btn-sm" onclick="accionModal(\''.$row->getId().'\', \'d\', \'PruebaArchivo\')" ><i class="material-icons">delete</i></button>':''; 
					
					include_once '../md/AsambleaModel.php';
					$Asamblea = new AsambleaModel();
					$Encontrado = $Asamblea->read($row->getAsamblea());
				
				

					echo '
					<tr>
						<td scope="col" style="width:25%">
							<img class="img-fluid" style="max-width:15%" src="PruebaArchivoController.php?Foto_id='. $row->getId() . '" alt="PruebaArchivoFoto"/>
						</td>
						
						<td scope="col" style="width:25%">
							<a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Asamblea\')" >
								'.$Encontrado->getNombre() .'
							</a>
						</td>
						
						<td scope="col" style="width:25%">
							<img class="img-fluid" style="max-width:15%" src="PruebaArchivoController.php?Icono_id='. $row->getId() . '" alt="PruebaArchivoIcono"/>
						</td>
						
						<td scope="col" style="width:25%">
							<div class="btn-group" role="group" aria-label="Basic example">
								'.$readButton.'
								'.$updateButton.' 
								'.$deleteButton.'
				   			</div>
					   </td>
				   </tr>';
			   }
		   ?>
		   </tbody>
	   </table>
	   
   
