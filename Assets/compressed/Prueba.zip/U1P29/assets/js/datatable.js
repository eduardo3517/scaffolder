
	$(document).ready(function () {
		
	$('#dtTipoUsuario').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtUsuario').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtEntidadSeguridad').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtAccionSeguridad').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtSeguridad').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtAsamblea').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtOtra').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtPruebaArchivo').DataTable({
		"pagingType": "full_numbers" 
	});
	$('.dataTables_length').addClass('bs-select');
});
