<?php
include_once "database.php";

Class AsambleaModel {

	private $id;
	private $Nombre;
	private $Fecha;
	private $Contrasena;
	private $Cantidad;
	private $CorreoElectronico;
	private $Hora;
	private $HoraFecha;
	private $TipoUsuario;
	private $FechaActual;
	private $Icono;
	private $IconoType;
	private	$db;

	function __construct (){

	  	$this->db="Prueba";
    	
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getId(){
		return $this->id;
	}

	
	public function getNombre(){
		return $this->Nombre;
	}

	public function setNombre($Nombre){
		$this->Nombre = $Nombre;
	}

	
	public function getFecha(){
		return $this->Fecha;
	}

	public function setFecha($Fecha){
		$this->Fecha = $Fecha;
	}

	
	public function getContrasena(){
		return $this->Contrasena;
	}

	public function setContrasena($Contrasena){
		$this->Contrasena = $Contrasena;
	}

	
	public function getCantidad(){
		return $this->Cantidad;
	}

	public function setCantidad($Cantidad){
		$this->Cantidad = $Cantidad;
	}

	
	public function getCorreoElectronico(){
		return $this->CorreoElectronico;
	}

	public function setCorreoElectronico($CorreoElectronico){
		$this->CorreoElectronico = $CorreoElectronico;
	}

	
	public function getHora(){
		return $this->Hora;
	}

	public function setHora($Hora){
		$this->Hora = $Hora;
	}

	
	public function getHoraFecha(){
		return $this->HoraFecha;
	}

	public function setHoraFecha($HoraFecha){
		$this->HoraFecha = $HoraFecha;
	}

	
	public function getTipoUsuario(){
		return $this->TipoUsuario;
	}

	public function setTipoUsuario($TipoUsuario){
		$this->TipoUsuario = $TipoUsuario;
	}

	
	public function getFechaActual(){
		return $this->FechaActual;
	}

	public function setFechaActual($FechaActual){
		$this->FechaActual = $FechaActual;
	}

	
	public function getIcono(){
		return $this->Icono;
	}

	public function setIcono($Icono){
		$this->Icono = $Icono;
	}

	
	public function getIconoType(){
		return $this->IconoType;
	}

	public function setIconoType($IconoType){
		$this->IconoType = $IconoType;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".Asamblea (
			Nombre, 
			Fecha, 
			Contrasena, 
			Cantidad, 
			CorreoElectronico, 
			Hora, 
			HoraFecha, 
			TipoUsuario, 
			Icono, 
			IconoType) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array(
				$this->Nombre, 
				$this->Fecha, 
				password_hash($this->Contrasena, PASSWORD_DEFAULT), 
				$this->Cantidad, 
				$this->CorreoElectronico, 
				$this->Hora, 
				$this->HoraFecha, 
				$this->TipoUsuario, 
				$this->Icono, 
				$this->IconoType["mime"]));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$Asambleas = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Asamblea";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$Asamblea = new AsambleaModel();
			$Asamblea->setId($row["id"]);
			$Asamblea->setNombre($row["Nombre"]);
			$Asamblea->setFecha($row["Fecha"]);
			$Asamblea->setContrasena($row["Contrasena"]);
			$Asamblea->setCantidad($row["Cantidad"]);
			$Asamblea->setCorreoElectronico($row["CorreoElectronico"]);
			$Asamblea->setHora($row["Hora"]);
			$Asamblea->setHoraFecha($row["HoraFecha"]);
			$Asamblea->setTipoUsuario($row["TipoUsuario"]);
			$Asamblea->setFechaActual($row["FechaActual"]);
			$Asamblea->setIcono($row["Icono"]);
		  	array_push ($Asambleas, $Asamblea);
		}
		Database::disconnect();
		return $Asambleas;
	}

	function read($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Asamblea WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$Asamblea = new AsambleaModel();
		$Asamblea->setId($row["id"]);
		$Asamblea->setNombre($row["Nombre"]);
		$Asamblea->setFecha($row["Fecha"]);
		$Asamblea->setContrasena($row["Contrasena"]);
		$Asamblea->setCantidad($row["Cantidad"]);
		$Asamblea->setCorreoElectronico($row["CorreoElectronico"]);
		$Asamblea->setHora($row["Hora"]);
		$Asamblea->setHoraFecha($row["HoraFecha"]);
		$Asamblea->setTipoUsuario($row["TipoUsuario"]);
		$Asamblea->setFechaActual($row["FechaActual"]);
		$Asamblea->setIcono($row["Icono"]);
		return $Asamblea;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".Asamblea WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".Asamblea SET Nombre=?, Fecha=?, Contrasena=?, Cantidad=?, CorreoElectronico=?, Hora=?, HoraFecha=?, TipoUsuario=?, Icono=?, IconoType =? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->Icono, $this->IconoType["mime"], $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
