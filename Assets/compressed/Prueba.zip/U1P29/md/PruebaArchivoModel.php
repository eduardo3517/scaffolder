<?php
include_once "database.php";

Class PruebaArchivoModel {

	private $id;
	private $Foto;
	private $FotoType;
	private $Asamblea;
	private $Icono;
	private $IconoType;
	private	$db;

	function __construct (){

	  	$this->db="Prueba";
    	
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getId(){
		return $this->id;
	}

	
	public function getFoto(){
		return $this->Foto;
	}

	public function setFoto($Foto){
		$this->Foto = $Foto;
	}

	
	public function getFotoType(){
		return $this->FotoType;
	}

	public function setFotoType($FotoType){
		$this->FotoType = $FotoType;
	}

	
	public function getAsamblea(){
		return $this->Asamblea;
	}

	public function setAsamblea($Asamblea){
		$this->Asamblea = $Asamblea;
	}

	
	public function getIcono(){
		return $this->Icono;
	}

	public function setIcono($Icono){
		$this->Icono = $Icono;
	}

	
	public function getIconoType(){
		return $this->IconoType;
	}

	public function setIconoType($IconoType){
		$this->IconoType = $IconoType;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".PruebaArchivo (
			Foto, 
			FotoType, 
			Asamblea, 
			Icono, 
			IconoType) values (?, ?, ?, ?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array(
				$this->Foto, 
				$this->FotoType["mime"], 
				$this->Asamblea, 
				$this->Icono, 
				$this->IconoType["mime"]));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$PruebaArchivos = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".PruebaArchivo";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$PruebaArchivo = new PruebaArchivoModel();
			$PruebaArchivo->setId($row["id"]);
			$PruebaArchivo->setFoto($row["Foto"]);
			$PruebaArchivo->setAsamblea($row["Asamblea"]);
			$PruebaArchivo->setIcono($row["Icono"]);
		  	array_push ($PruebaArchivos, $PruebaArchivo);
		}
		Database::disconnect();
		return $PruebaArchivos;
	}

	function read($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".PruebaArchivo WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$PruebaArchivo = new PruebaArchivoModel();
		$PruebaArchivo->setId($row["id"]);
		$PruebaArchivo->setFoto($row["Foto"]);
		$PruebaArchivo->setAsamblea($row["Asamblea"]);
		$PruebaArchivo->setIcono($row["Icono"]);
		return $PruebaArchivo;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".PruebaArchivo WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".PruebaArchivo SET Foto=?, FotoType =?, Asamblea=?, Icono=?, IconoType =? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->Icono, $this->IconoType["mime"], $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
