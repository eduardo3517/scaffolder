

		<h3 class="display-6" id="tableDesc">Listado de EquipoAfectado</h3>
	   	<br>
	   
	   	<table id="dtEquipoAfectado" class="table table-striped table-bordered table-sm" aria-describedby="tableDesc">
		   
		   	<thead class="thead-light">
			   	<tr>
						<th scope="col" style="width:25%">
							Equipo
						</th>
						<th scope="col" style="width:25%">
							AccionCorrectiva
						</th>
						<th scope="col" style="width:25%">
							Corregido
						</th>
				   <th scope="col" style="width:25%">
					   Acciones
				   </th>
			   </tr>
		   </thead>
		   <tbody>
		   <?php
			   

			   $EquipoAfectados = $this->list();
			   foreach ($EquipoAfectados as $row) {
				   echo '<tr>';
						include_once '../md/EquipoModel.php';
						$Equipo = new EquipoModel();
						$Encontrado = $Equipo->read($row->getEquipo());
						echo '<td scope="col" style="width:25%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Equipo\')" >'.$Encontrado->getCodigo() .'</a></td>';
						include_once '../md/AccionCorrectivaModel.php';
						$AccionCorrectiva = new AccionCorrectivaModel();
						$Encontrado = $AccionCorrectiva->read($row->getAccionCorrectiva());
						echo '<td scope="col" style="width:25%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'AccionCorrectiva\')" >'.$Encontrado->getNumeroId() .'</a></td>';
						echo '<td scope="col" style="width:25%">'. $row->getCorregido() . '</td>';
				   echo '<td scope="col" style="width:25%">
					   <div class="btn-group" role="group" aria-label="Basic example">';

				   echo in_array(1, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'r\', \'EquipoAfectado\')" ><i class="material-icons">remove_red_eye</i></button>':''; 
				   echo in_array(4, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'u\', \'EquipoAfectado\')" ><i class="material-icons">create</i></button>':''; 
				   echo in_array(3, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-danger btn-sm" onclick="accionModal(\''.$row->getId().'\', \'d\', \'EquipoAfectado\')" ><i class="material-icons">delete</i></button>':''; 
				   echo '</div>
					   </td>
				   </tr>';
			   }
		   ?>
		   </tbody>
	   </table>
	   
   
