
	<?php
		$EquipoAfectado = $this->read($_POST['id']);
	?>
	<div class="modal-header">
		<h5 class="modal-title" id="exampleModalLongTitle">Detalle de EquipoAfectado</h5>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>

	<div class="modal-body">
		<div class="col-sm-10 offset-md-1">
			<div class="card border-light">
				<div class="card-header">Equipo</div>
				<div class="card-body">
					<p class="card-text"> 
					<?php
						include_once '../md/EquipoModel.php';
						$Equipo = new EquipoModel();
						$Encontrado = $Equipo->read($EquipoAfectado->getEquipo());
						echo $Encontrado->getCodigo();
					?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">AccionCorrectiva</div>
				<div class="card-body">
					<p class="card-text"> 
					<?php
						include_once '../md/AccionCorrectivaModel.php';
						$AccionCorrectiva = new AccionCorrectivaModel();
						$Encontrado = $AccionCorrectiva->read($EquipoAfectado->getAccionCorrectiva());
						echo $Encontrado->getNumeroId();
					?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Corregido</div>
				<div class="card-body">
					<p class="card-text"><?php echo $EquipoAfectado->getCorregido();?></p>
				</div>
			</div>
		</div> 
	</div> 
	<div class="modal-footer">
		<button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Atrás</button>
	</div>
