
	<?php
		$EquipoAfectado = $this->read($_POST['id']);
	?>
	<form action="EquipoAfectadoController.php" method="post" enctype="multipart/form-data">
		<div class="modal-header">
			<h5 class="modal-title" id="exampleModalLongTitle">Modificar EquipoAfectado</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
		<div class="modal-body">
			<div class = "row">
				<div class ="col">
				</div>
				<div class ="col-10">
					<h4 class="display-12">Llena todos los campos requeridos.</h4>
					<br>
					<input class="form-control" name="c" type="hidden" value="a" >
					<input class="form-control" name="id" type="hidden" value="<?php echo $EquipoAfectado->getId();?>" >

					<label for="NumeroId">Equipo</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<select class="form-control" name="Equipo" required>
								<?php
									include "../md/EquipoModel.php";
									$Equipo = new EquipoModel();
									$Equipos = $Equipo->list();

									foreach ($Equipos as $Fila){
										$selected = $EquipoAfectado->getEquipo()==$Fila->getId()?'" selected="selected">':'" >';
										echo '<option value="'.$Fila->getId().$selected.$Fila->getCodigo().'</option>';
									}
								?>
							</select>
						</div>
					</div>

					<label for="NumeroId">AccionCorrectiva</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<select class="form-control" name="AccionCorrectiva" required>
								<?php
									include "../md/AccionCorrectivaModel.php";
									$AccionCorrectiva = new AccionCorrectivaModel();
									$AccionCorrectivas = $AccionCorrectiva->list();

									foreach ($AccionCorrectivas as $Fila){
										$selected = $EquipoAfectado->getAccionCorrectiva()==$Fila->getId()?'" selected="selected">':'" >';
										echo '<option value="'.$Fila->getId().$selected.$Fila->getNumeroId().'</option>';
									}
								?>
							</select>
						</div>
					</div>
					<label for="Corregido">Corregido</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<input class="form-control" name="Corregido" type="Numérico" title="Este campo es sólo números." <?php echo 'value="'.$EquipoAfectado->getCorregido().'"'?>  required>
						</div>
					</div>
				</div>
				<div class ="col">
				</div>
			</div>
		</div>
		<div class="modal-footer">
			<button type="submit" class="btn btn-outline-primary btn-sm">Actualizar</button>
			<button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Cancelar</button>
		</div>
	</form>

