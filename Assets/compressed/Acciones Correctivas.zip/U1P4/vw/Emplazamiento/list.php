

		<h3 class="display-6" id="tableDesc">Listado de Emplazamiento</h3>
	   	<br>
	   
	   	<table id="dtEmplazamiento" class="table table-striped table-bordered table-sm" aria-describedby="tableDesc">
		   
		   	<thead class="thead-light">
			   	<tr>
						<th scope="col" style="width:25%">
							Codigo
						</th>
						<th scope="col" style="width:25%">
							Supervisor
						</th>
						<th scope="col" style="width:25%">
							OficinaVentas
						</th>
				   <th scope="col" style="width:25%">
					   Acciones
				   </th>
			   </tr>
		   </thead>
		   <tbody>
		   <?php
			   

			   $Emplazamientos = $this->list();
			   foreach ($Emplazamientos as $row) {
				   echo '<tr>';
						echo '<td scope="col" style="width:25%">'. $row->getCodigo() . '</td>';
						include_once '../md/UsuarioModel.php';
						$Usuario = new UsuarioModel();
						$Encontrado = $Usuario->read($row->getSupervisor());
						echo '<td scope="col" style="width:25%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Usuario\')" >'.$Encontrado->getNombre() .'</a></td>';
						include_once '../md/OficinaVentasModel.php';
						$OficinaVentas = new OficinaVentasModel();
						$Encontrado = $OficinaVentas->read($row->getOficinaVentas());
						echo '<td scope="col" style="width:25%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'OficinaVentas\')" >'.$Encontrado->getCodigo() .'</a></td>';
				   echo '<td scope="col" style="width:25%">
					   <div class="btn-group" role="group" aria-label="Basic example">';

				   echo in_array(1, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'r\', \'Emplazamiento\')" ><i class="material-icons">remove_red_eye</i></button>':''; 
				   echo in_array(4, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'u\', \'Emplazamiento\')" ><i class="material-icons">create</i></button>':''; 
				   echo in_array(3, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-danger btn-sm" onclick="accionModal(\''.$row->getId().'\', \'d\', \'Emplazamiento\')" ><i class="material-icons">delete</i></button>':''; 
				   echo '</div>
					   </td>
				   </tr>';
			   }
		   ?>
		   </tbody>
	   </table>
	   
   
