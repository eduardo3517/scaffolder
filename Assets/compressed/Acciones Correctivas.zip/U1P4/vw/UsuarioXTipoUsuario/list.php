

		<h3 class="display-6" id="tableDesc">Listado de UsuarioXTipoUsuario</h3>
	   	<br>
	   
	   	<table id="dtUsuarioXTipoUsuario" class="table table-striped table-bordered table-sm" aria-describedby="tableDesc">
		   
		   	<thead class="thead-light">
			   	<tr>
						<th scope="col" style="width:33.333333333333%">
							Usuario
						</th>
						<th scope="col" style="width:33.333333333333%">
							TipoUsuario
						</th>
				   <th scope="col" style="width:33.333333333333%">
					   Acciones
				   </th>
			   </tr>
		   </thead>
		   <tbody>
		   <?php
			   

			   $UsuarioXTipoUsuarios = $this->list();
			   foreach ($UsuarioXTipoUsuarios as $row) {
				   echo '<tr>';
						include_once '../md/UsuarioModel.php';
						$Usuario = new UsuarioModel();
						$Encontrado = $Usuario->read($row->getUsuario());
						echo '<td scope="col" style="width:33.333333333333%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Usuario\')" >'.$Encontrado->getNombre() .'</a></td>';
						include_once '../md/TipoUsuarioModel.php';
						$TipoUsuario = new TipoUsuarioModel();
						$Encontrado = $TipoUsuario->read($row->getTipoUsuario());
						echo '<td scope="col" style="width:33.333333333333%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'TipoUsuario\')" >'.$Encontrado->getNombre() .'</a></td>';
				   echo '<td scope="col" style="width:33.333333333333%">
					   <div class="btn-group" role="group" aria-label="Basic example">';

				   echo in_array(1, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'r\', \'UsuarioXTipoUsuario\')" ><i class="material-icons">remove_red_eye</i></button>':''; 
				   echo in_array(4, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'u\', \'UsuarioXTipoUsuario\')" ><i class="material-icons">create</i></button>':''; 
				   echo in_array(3, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-danger btn-sm" onclick="accionModal(\''.$row->getId().'\', \'d\', \'UsuarioXTipoUsuario\')" ><i class="material-icons">delete</i></button>':''; 
				   echo '</div>
					   </td>
				   </tr>';
			   }
		   ?>
		   </tbody>
	   </table>
	   
   
