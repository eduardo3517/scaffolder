
	<div class="modal-header">
		<h5 class="modal-title" id="exampleModalLongTitle">Agregar OficinaVentas</h5>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>
	<div class="modal-body">
		<div class="row">
			<div class ="col">
			</div>
			<div class ="col-10">
				<h4 class="display-6">Llena todos los campos requeridos.</h4>
				<br>
				<form action="OficinaVentasController.php" method="post" enctype="multipart/form-data">
					<input class="form-control" name="c" type="hidden" value="g" >
					<label for="Ciudad">Ciudad</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<select class="form-control" name="Ciudad" required>
								<?php
									include "../md/CiudadModel.php";
									$Ciudad = new CiudadModel();
									$Ciudads = $Ciudad->list();

									foreach ($Ciudads as $Fila){
										echo '<option value="'.$Fila->getId().'">'.$Fila->getNombre().'</option>';
									}
								?>
							</select>
						</div>
					</div>
					<label for="Codigo">Codigo</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<input class="form-control" name="Codigo" type="text" title="Este campo es sólo números o letras." required>
						</div>
					</div>
					<label for="Zona">Zona</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<select class="form-control" name="Zona" required>
								<?php
									include "../md/ZonaModel.php";
									$Zona = new ZonaModel();
									$Zonas = $Zona->list();

									foreach ($Zonas as $Fila){
										echo '<option value="'.$Fila->getId().'">'.$Fila->getNombre().'</option>';
									}
								?>
							</select>
						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-outline-primary">Guardar</button>
						<button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cancelar</button>
					</div>
				</form>
				</div>
				<div class ="col">
				</div>
			</div>
		</div>
