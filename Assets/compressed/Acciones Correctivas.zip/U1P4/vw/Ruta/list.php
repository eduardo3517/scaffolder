

		<h3 class="display-6" id="tableDesc">Listado de Ruta</h3>
	   	<br>
	   
	   	<table id="dtRuta" class="table table-striped table-bordered table-sm" aria-describedby="tableDesc">
		   
		   	<thead class="thead-light">
			   	<tr>
						<th scope="col" style="width:25%">
							Codigo
						</th>
						<th scope="col" style="width:25%">
							Tecnico
						</th>
						<th scope="col" style="width:25%">
							Emplazamiento
						</th>
				   <th scope="col" style="width:25%">
					   Acciones
				   </th>
			   </tr>
		   </thead>
		   <tbody>
		   <?php
			   

			   $Rutas = $this->list();
			   foreach ($Rutas as $row) {
				   echo '<tr>';
						echo '<td scope="col" style="width:25%">'. $row->getCodigo() . '</td>';
						include_once '../md/UsuarioModel.php';
						$Usuario = new UsuarioModel();
						$Encontrado = $Usuario->read($row->getTecnico());
						echo '<td scope="col" style="width:25%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Usuario\')" >'.$Encontrado->getNombre() .'</a></td>';
						include_once '../md/EmplazamientoModel.php';
						$Emplazamiento = new EmplazamientoModel();
						$Encontrado = $Emplazamiento->read($row->getEmplazamiento());
						echo '<td scope="col" style="width:25%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Emplazamiento\')" >'.$Encontrado->getCodigo() .'</a></td>';
				   echo '<td scope="col" style="width:25%">
					   <div class="btn-group" role="group" aria-label="Basic example">';

				   echo in_array(1, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'r\', \'Ruta\')" ><i class="material-icons">remove_red_eye</i></button>':''; 
				   echo in_array(4, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'u\', \'Ruta\')" ><i class="material-icons">create</i></button>':''; 
				   echo in_array(3, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-danger btn-sm" onclick="accionModal(\''.$row->getId().'\', \'d\', \'Ruta\')" ><i class="material-icons">delete</i></button>':''; 
				   echo '</div>
					   </td>
				   </tr>';
			   }
		   ?>
		   </tbody>
	   </table>
	   
   
