
	<?php
		$Equipo = $this->read($_POST['id']);
	?>
	<div class="modal-header">
		<h5 class="modal-title" id="exampleModalLongTitle">Detalle de Equipo</h5>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>

	<div class="modal-body">
		<div class="col-sm-10 offset-md-1">
			<div class="card border-light">
				<div class="card-header">Codigo</div>
				<div class="card-body">
					<p class="card-text"><?php echo $Equipo->getCodigo();?></p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Ruta</div>
				<div class="card-body">
					<p class="card-text"> 
					<?php
						include_once '../md/RutaModel.php';
						$Ruta = new RutaModel();
						$Encontrado = $Ruta->read($Equipo->getRuta());
						echo $Encontrado->getCodigo();
					?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Estado</div>
				<div class="card-body">
					<p class="card-text"> 
					<?php
						include_once '../md/EstadoEquipoModel.php';
						$EstadoEquipo = new EstadoEquipoModel();
						$Encontrado = $EstadoEquipo->read($Equipo->getEstado());
						echo $Encontrado->getNombre();
					?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Tipo</div>
				<div class="card-body">
					<p class="card-text"> 
					<?php
						include_once '../md/TipoEquipoModel.php';
						$TipoEquipo = new TipoEquipoModel();
						$Encontrado = $TipoEquipo->read($Equipo->getTipo());
						echo $Encontrado->getDescripcion();
					?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Denominacion</div>
				<div class="card-body">
					<p class="card-text"><?php echo $Equipo->getDenominacion();?></p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Direccion</div>
				<div class="card-body">
					<p class="card-text"><?php echo $Equipo->getDireccion();?></p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Ciudad</div>
				<div class="card-body">
					<p class="card-text"> 
					<?php
						include_once '../md/CiudadModel.php';
						$Ciudad = new CiudadModel();
						$Encontrado = $Ciudad->read($Equipo->getCiudad());
						echo $Encontrado->getNombre();
					?>
					</p>
				</div>
			</div>
		</div> 
	</div> 
	<div class="modal-footer">
		<button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Atrás</button>
	</div>
