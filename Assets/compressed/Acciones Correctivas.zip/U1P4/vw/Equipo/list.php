

		<h3 class="display-6" id="tableDesc">Listado de Equipo</h3>
	   	<br>
	   
	   	<table id="dtEquipo" class="table table-striped table-bordered table-sm" aria-describedby="tableDesc">
		   
		   	<thead class="thead-light">
			   	<tr>
						<th scope="col" style="width:12.5%">
							Codigo
						</th>
						<th scope="col" style="width:12.5%">
							Ruta
						</th>
						<th scope="col" style="width:12.5%">
							Estado
						</th>
						<th scope="col" style="width:12.5%">
							Tipo
						</th>
						<th scope="col" style="width:12.5%">
							Denominacion
						</th>
						<th scope="col" style="width:12.5%">
							Direccion
						</th>
						<th scope="col" style="width:12.5%">
							Ciudad
						</th>
				   <th scope="col" style="width:12.5%">
					   Acciones
				   </th>
			   </tr>
		   </thead>
		   <tbody>
		   <?php
			   

			   $Equipos = $this->list();
			   foreach ($Equipos as $row) {
				   echo '<tr>';
						echo '<td scope="col" style="width:12.5%">'. $row->getCodigo() . '</td>';
						include_once '../md/RutaModel.php';
						$Ruta = new RutaModel();
						$Encontrado = $Ruta->read($row->getRuta());
						echo '<td scope="col" style="width:12.5%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Ruta\')" >'.$Encontrado->getCodigo() .'</a></td>';
						include_once '../md/EstadoEquipoModel.php';
						$EstadoEquipo = new EstadoEquipoModel();
						$Encontrado = $EstadoEquipo->read($row->getEstado());
						echo '<td scope="col" style="width:12.5%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'EstadoEquipo\')" >'.$Encontrado->getNombre() .'</a></td>';
						include_once '../md/TipoEquipoModel.php';
						$TipoEquipo = new TipoEquipoModel();
						$Encontrado = $TipoEquipo->read($row->getTipo());
						echo '<td scope="col" style="width:12.5%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'TipoEquipo\')" >'.$Encontrado->getDescripcion() .'</a></td>';
						echo '<td scope="col" style="width:12.5%">'. $row->getDenominacion() . '</td>';
						echo '<td scope="col" style="width:12.5%">'. $row->getDireccion() . '</td>';
						include_once '../md/CiudadModel.php';
						$Ciudad = new CiudadModel();
						$Encontrado = $Ciudad->read($row->getCiudad());
						echo '<td scope="col" style="width:12.5%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Ciudad\')" >'.$Encontrado->getNombre() .'</a></td>';
				   echo '<td scope="col" style="width:12.5%">
					   <div class="btn-group" role="group" aria-label="Basic example">';

				   echo in_array(1, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'r\', \'Equipo\')" ><i class="material-icons">remove_red_eye</i></button>':''; 
				   echo in_array(4, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'u\', \'Equipo\')" ><i class="material-icons">create</i></button>':''; 
				   echo in_array(3, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-danger btn-sm" onclick="accionModal(\''.$row->getId().'\', \'d\', \'Equipo\')" ><i class="material-icons">delete</i></button>':''; 
				   echo '</div>
					   </td>
				   </tr>';
			   }
		   ?>
		   </tbody>
	   </table>
	   
   
