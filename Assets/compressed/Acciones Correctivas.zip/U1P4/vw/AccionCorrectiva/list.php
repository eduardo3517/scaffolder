

		<h3 class="display-6" id="tableDesc">Listado de AccionCorrectiva</h3>
	   	<br>
	   
	   	<table id="dtAccionCorrectiva" class="table table-striped table-bordered table-sm" aria-describedby="tableDesc">
		   
		   	<thead class="thead-light">
			   	<tr>
						<th scope="col" style="width:12.5%">
							NumeroId
						</th>
						<th scope="col" style="width:12.5%">
							Descripcion
						</th>
						<th scope="col" style="width:12.5%">
							FechaVencimiento
						</th>
						<th scope="col" style="width:12.5%">
							Cumplimiento
						</th>
						<th scope="col" style="width:12.5%">
							TipoAccion
						</th>
						<th scope="col" style="width:12.5%">
							CargadoPor
						</th>
						<th scope="col" style="width:12.5%">
							CantEquiGrupo
						</th>
				   <th scope="col" style="width:12.5%">
					   Acciones
				   </th>
			   </tr>
		   </thead>
		   <tbody>
		   <?php
			   

			   $AccionCorrectivas = $this->list();
			   foreach ($AccionCorrectivas as $row) {
				   echo '<tr>';
						echo '<td scope="col" style="width:12.5%">'. $row->getNumeroId() . '</td>';
						echo '<td scope="col" style="width:12.5%">'. $row->getDescripcion() . '</td>';
						echo '<td scope="col" style="width:12.5%">'. $row->getFechaVencimiento() . '</td>';
						echo '<td scope="col" style="width:12.5%">'. $row->getCumplimiento() . '</td>';
						include_once '../md/TipoAccionCorrectivaModel.php';
						$TipoAccionCorrectiva = new TipoAccionCorrectivaModel();
						$Encontrado = $TipoAccionCorrectiva->read($row->getTipoAccion());
						echo '<td scope="col" style="width:12.5%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'TipoAccionCorrectiva\')" >'.$Encontrado->getNombre() .'</a></td>';
						include_once '../md/UsuarioModel.php';
						$Usuario = new UsuarioModel();
						$Encontrado = $Usuario->read($row->getCargadoPor());
						echo '<td scope="col" style="width:12.5%"><a data-toggle="modal" data-target="#modal" onclick="accionModal(\''.$Encontrado->getId().'\', \'r\', \'Usuario\')" >'.$Encontrado->getNombre() .'</a></td>';
						echo '<td scope="col" style="width:12.5%">'. $row->getCantEquiGrupo() . '</td>';
				   echo '<td scope="col" style="width:12.5%">
					   <div class="btn-group" role="group" aria-label="Basic example">';

				   echo in_array(1, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'r\', \'AccionCorrectiva\')" ><i class="material-icons">remove_red_eye</i></button>':''; 
				   echo in_array(4, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-secondary btn-sm" onclick="accionModal(\''.$row->getId().'\', \'u\', \'AccionCorrectiva\')" ><i class="material-icons">create</i></button>':''; 
				   echo in_array(3, $Permiso)?'<button type="button" data-toggle="modal" data-target="#modal" class="btn btn-outline-danger btn-sm" onclick="accionModal(\''.$row->getId().'\', \'d\', \'AccionCorrectiva\')" ><i class="material-icons">delete</i></button>':''; 
				   echo '</div>
					   </td>
				   </tr>';
			   }
		   ?>
		   </tbody>
	   </table>
	   
   
