
	<?php
		$AccionCorrectiva = $this->read($_POST['id']);
	?>
	<form action="AccionCorrectivaController.php" method="post" enctype="multipart/form-data">
		<div class="modal-header">
			<h5 class="modal-title" id="exampleModalLongTitle">Modificar AccionCorrectiva</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
		<div class="modal-body">
			<div class = "row">
				<div class ="col">
				</div>
				<div class ="col-10">
					<h4 class="display-12">Llena todos los campos requeridos.</h4>
					<br>
					<input class="form-control" name="c" type="hidden" value="a" >
					<input class="form-control" name="id" type="hidden" value="<?php echo $AccionCorrectiva->getId();?>" >
					<label for="NumeroId">NumeroId</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<input class="form-control" name="NumeroId" type="Cadena" title="Este campo es sólo números o letras." <?php echo 'value="'.$AccionCorrectiva->getNumeroId().'"'?>  required>
						</div>
					</div>
					<label for="Descripcion">Descripcion</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<input class="form-control" name="Descripcion" type="Cadena" title="Este campo es sólo números o letras." <?php echo 'value="'.$AccionCorrectiva->getDescripcion().'"'?>  required>
						</div>
					</div>
					<label for="FechaVencimiento">FechaVencimiento</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<input class="form-control" name="FechaVencimiento" type="Fecha" title="Este campo es sólo tipo fecha." <?php echo 'value="'.$AccionCorrectiva->getFechaVencimiento().'"'?>  required>
						</div>
					</div>
					<label for="Cumplimiento">Cumplimiento</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<input class="form-control" name="Cumplimiento" type="Numérico" title="Este campo es sólo números." <?php echo 'value="'.$AccionCorrectiva->getCumplimiento().'"'?>  required>
						</div>
					</div>

					<label for="NumeroId">TipoAccion</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<select class="form-control" name="TipoAccion" required>
								<?php
									include "../md/TipoAccionCorrectivaModel.php";
									$TipoAccionCorrectiva = new TipoAccionCorrectivaModel();
									$TipoAccionCorrectivas = $TipoAccionCorrectiva->list();

									foreach ($TipoAccionCorrectivas as $Fila){
										$selected = $AccionCorrectiva->getTipoAccion()==$Fila->getId()?'" selected="selected">':'" >';
										echo '<option value="'.$Fila->getId().$selected.$Fila->getNombre().'</option>';
									}
								?>
							</select>
						</div>
					</div>

					<label for="NumeroId">CargadoPor</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<select class="form-control" name="CargadoPor" required>
								<?php
									include "../md/UsuarioModel.php";
									$Usuario = new UsuarioModel();
									$Usuarios = $Usuario->list();

									foreach ($Usuarios as $Fila){
										$selected = $AccionCorrectiva->getCargadoPor()==$Fila->getId()?'" selected="selected">':'" >';
										echo '<option value="'.$Fila->getId().$selected.$Fila->getNombre().'</option>';
									}
								?>
							</select>
						</div>
					</div>
					<label for="CantEquiGrupo">CantEquiGrupo</label>
					<div class="form-group input-group">
						<div class="col-sm-12">
							<input class="form-control" name="CantEquiGrupo" type="Numérico" title="Este campo es sólo números." <?php echo 'value="'.$AccionCorrectiva->getCantEquiGrupo().'"'?>  required>
						</div>
					</div>
				</div>
				<div class ="col">
				</div>
			</div>
		</div>
		<div class="modal-footer">
			<button type="submit" class="btn btn-outline-primary btn-sm">Actualizar</button>
			<button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Cancelar</button>
		</div>
	</form>

