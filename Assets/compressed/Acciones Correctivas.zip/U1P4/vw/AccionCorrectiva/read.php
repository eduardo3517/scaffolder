
	<?php
		$AccionCorrectiva = $this->read($_POST['id']);
	?>
	<div class="modal-header">
		<h5 class="modal-title" id="exampleModalLongTitle">Detalle de AccionCorrectiva</h5>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>

	<div class="modal-body">
		<div class="col-sm-10 offset-md-1">
			<div class="card border-light">
				<div class="card-header">NumeroId</div>
				<div class="card-body">
					<p class="card-text"><?php echo $AccionCorrectiva->getNumeroId();?></p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Descripcion</div>
				<div class="card-body">
					<p class="card-text"><?php echo $AccionCorrectiva->getDescripcion();?></p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">FechaVencimiento</div>
				<div class="card-body">
					<p class="card-text"><?php echo $AccionCorrectiva->getFechaVencimiento();?></p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">Cumplimiento</div>
				<div class="card-body">
					<p class="card-text"><?php echo $AccionCorrectiva->getCumplimiento();?></p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">TipoAccion</div>
				<div class="card-body">
					<p class="card-text"> 
					<?php
						include_once '../md/TipoAccionCorrectivaModel.php';
						$TipoAccionCorrectiva = new TipoAccionCorrectivaModel();
						$Encontrado = $TipoAccionCorrectiva->read($AccionCorrectiva->getTipoAccion());
						echo $Encontrado->getNombre();
					?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">CargadoPor</div>
				<div class="card-body">
					<p class="card-text"> 
					<?php
						include_once '../md/UsuarioModel.php';
						$Usuario = new UsuarioModel();
						$Encontrado = $Usuario->read($AccionCorrectiva->getCargadoPor());
						echo $Encontrado->getNombre();
					?>
					</p>
				</div>
			</div>
			<div class="card border-light">
				<div class="card-header">CantEquiGrupo</div>
				<div class="card-body">
					<p class="card-text"><?php echo $AccionCorrectiva->getCantEquiGrupo();?></p>
				</div>
			</div>
		</div> 
	</div> 
	<div class="modal-footer">
		<button type="button" class="btn btn-outline-secondary btn-sm" data-dismiss="modal">Atrás</button>
	</div>
