<?php
	include_once "database.php";

Class TipoAccionCorrectivaModel {

	private $id;
	private $Nombre;
	private $Descripcion;
	private	$db;

	function __construct (){

	  	$this->db="u238953651_acco";
    	
	}

	public function getId(){
		return $this->id;
	}

	
	public function getNombre(){
		return $this->Nombre;
	}

	public function setNombre($Nombre){
		$this->Nombre = $Nombre;
	}

	
	public function getDescripcion(){
		return $this->Descripcion;
	}

	public function setDescripcion($Descripcion){
		$this->Descripcion = $Descripcion;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".TipoAccionCorrectiva (Nombre, Descripcion) values(?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array($this->Nombre, $this->Descripcion));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$TipoAccionCorrectivas = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".TipoAccionCorrectiva";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$TipoAccionCorrectiva = new TipoAccionCorrectivaModel();
			
			$TipoAccionCorrectiva->setNombre($row["Nombre"]);
			$TipoAccionCorrectiva->setDescripcion($row["Descripcion"]);
		  	array_push ($TipoAccionCorrectivas, new TipoAccionCorrectivaModel($row["id"], 
		}
		Database::disconnect();
		return $TipoAccionCorrectivas;
	}

	function read($id){
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".TipoAccionCorrectiva WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$TipoAccionCorrectiva = new TipoAccionCorrectivaModel();
		
		$TipoAccionCorrectiva->setNombre($row["Nombre"]);
		$TipoAccionCorrectiva->setDescripcion($row["Descripcion"]);
		return $TipoAccionCorrectiva;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".TipoAccionCorrectiva WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".TipoAccionCorrectiva SET Nombre=?, Descripcion=? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->Nombre, $this->Descripcion, $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
