<?php
	include_once "database.php";

Class TipoEquipoModel {

	private $id;
	private $Codigo;
	private $Descripcion;
	private	$db;

	function __construct (){

	  	$this->db="u238953651_acco";
    	
	}

	public function getId(){
		return $this->id;
	}

	
	public function getCodigo(){
		return $this->Codigo;
	}

	public function setCodigo($Codigo){
		$this->Codigo = $Codigo;
	}

	
	public function getDescripcion(){
		return $this->Descripcion;
	}

	public function setDescripcion($Descripcion){
		$this->Descripcion = $Descripcion;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".TipoEquipo (Codigo, Descripcion) values(?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array($this->Codigo, $this->Descripcion));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$TipoEquipos = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".TipoEquipo";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$TipoEquipo = new TipoEquipoModel();
			
			$TipoEquipo->setCodigo($row["Codigo"]);
			$TipoEquipo->setDescripcion($row["Descripcion"]);
		  	array_push ($TipoEquipos, new TipoEquipoModel($row["id"], 
		}
		Database::disconnect();
		return $TipoEquipos;
	}

	function read($id){
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".TipoEquipo WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$TipoEquipo = new TipoEquipoModel();
		
		$TipoEquipo->setCodigo($row["Codigo"]);
		$TipoEquipo->setDescripcion($row["Descripcion"]);
		return $TipoEquipo;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".TipoEquipo WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".TipoEquipo SET Codigo=?, Descripcion=? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->Codigo, $this->Descripcion, $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
