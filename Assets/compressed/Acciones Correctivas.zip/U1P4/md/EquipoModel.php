<?php
	include_once "database.php";

Class EquipoModel {

	private $id;
	private $Codigo;
	private $Ruta;
	private $Estado;
	private $Tipo;
	private $Denominacion;
	private $Direccion;
	private $Ciudad;
	private	$db;

	function __construct (){

	  	$this->db="u238953651_acco";
    	
	}

	public function getId(){
		return $this->id;
	}

	
	public function getCodigo(){
		return $this->Codigo;
	}

	public function setCodigo($Codigo){
		$this->Codigo = $Codigo;
	}

	
	public function getRuta(){
		return $this->Ruta;
	}

	public function setRuta($Ruta){
		$this->Ruta = $Ruta;
	}

	
	public function getEstado(){
		return $this->Estado;
	}

	public function setEstado($Estado){
		$this->Estado = $Estado;
	}

	
	public function getTipo(){
		return $this->Tipo;
	}

	public function setTipo($Tipo){
		$this->Tipo = $Tipo;
	}

	
	public function getDenominacion(){
		return $this->Denominacion;
	}

	public function setDenominacion($Denominacion){
		$this->Denominacion = $Denominacion;
	}

	
	public function getDireccion(){
		return $this->Direccion;
	}

	public function setDireccion($Direccion){
		$this->Direccion = $Direccion;
	}

	
	public function getCiudad(){
		return $this->Ciudad;
	}

	public function setCiudad($Ciudad){
		$this->Ciudad = $Ciudad;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".Equipo (Codigo, Ruta, Estado, Tipo, Denominacion, Direccion, Ciudad) values(?, ?, ?, ?, ?, ?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array($this->Codigo, $this->Ruta, $this->Estado, $this->Tipo, $this->Denominacion, $this->Direccion, $this->Ciudad));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$Equipos = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Equipo";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$Equipo = new EquipoModel();
			
			$Equipo->setCodigo($row["Codigo"]);
			$Equipo->setRuta($row["Ruta"]);
			$Equipo->setEstado($row["Estado"]);
			$Equipo->setTipo($row["Tipo"]);
			$Equipo->setDenominacion($row["Denominacion"]);
			$Equipo->setDireccion($row["Direccion"]);
			$Equipo->setCiudad($row["Ciudad"]);
		  	array_push ($Equipos, new EquipoModel($row["id"], 
		}
		Database::disconnect();
		return $Equipos;
	}

	function read($id){
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Equipo WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$Equipo = new EquipoModel();
		
		$Equipo->setCodigo($row["Codigo"]);
		$Equipo->setRuta($row["Ruta"]);
		$Equipo->setEstado($row["Estado"]);
		$Equipo->setTipo($row["Tipo"]);
		$Equipo->setDenominacion($row["Denominacion"]);
		$Equipo->setDireccion($row["Direccion"]);
		$Equipo->setCiudad($row["Ciudad"]);
		return $Equipo;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".Equipo WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".Equipo SET Codigo=?, Ruta=?, Estado=?, Tipo=?, Denominacion=?, Direccion=?, Ciudad=? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->Codigo, $this->Ruta, $this->Estado, $this->Tipo, $this->Denominacion, $this->Direccion, $this->Ciudad, $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
