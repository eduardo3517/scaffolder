<?php
	include_once "database.php";

Class EmplazamientoModel {

	private $id;
	private $Codigo;
	private $Supervisor;
	private $OficinaVentas;
	private	$db;

	function __construct (){

	  	$this->db="u238953651_acco";
    	
	}

	public function getId(){
		return $this->id;
	}

	
	public function getCodigo(){
		return $this->Codigo;
	}

	public function setCodigo($Codigo){
		$this->Codigo = $Codigo;
	}

	
	public function getSupervisor(){
		return $this->Supervisor;
	}

	public function setSupervisor($Supervisor){
		$this->Supervisor = $Supervisor;
	}

	
	public function getOficinaVentas(){
		return $this->OficinaVentas;
	}

	public function setOficinaVentas($OficinaVentas){
		$this->OficinaVentas = $OficinaVentas;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".Emplazamiento (Codigo, Supervisor, OficinaVentas) values(?, ?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array($this->Codigo, $this->Supervisor, $this->OficinaVentas));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$Emplazamientos = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Emplazamiento";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$Emplazamiento = new EmplazamientoModel();
			
			$Emplazamiento->setCodigo($row["Codigo"]);
			$Emplazamiento->setSupervisor($row["Supervisor"]);
			$Emplazamiento->setOficinaVentas($row["OficinaVentas"]);
		  	array_push ($Emplazamientos, new EmplazamientoModel($row["id"], 
		}
		Database::disconnect();
		return $Emplazamientos;
	}

	function read($id){
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".Emplazamiento WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$Emplazamiento = new EmplazamientoModel();
		
		$Emplazamiento->setCodigo($row["Codigo"]);
		$Emplazamiento->setSupervisor($row["Supervisor"]);
		$Emplazamiento->setOficinaVentas($row["OficinaVentas"]);
		return $Emplazamiento;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".Emplazamiento WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".Emplazamiento SET Codigo=?, Supervisor=?, OficinaVentas=? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->Codigo, $this->Supervisor, $this->OficinaVentas, $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
