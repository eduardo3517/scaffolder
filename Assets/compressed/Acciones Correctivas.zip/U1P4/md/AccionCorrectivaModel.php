<?php
	include_once "database.php";

Class AccionCorrectivaModel {

	private $id;
	private $NumeroId;
	private $Descripcion;
	private $FechaVencimiento;
	private $Cumplimiento;
	private $TipoAccion;
	private $CargadoPor;
	private $CantEquiGrupo;
	private	$db;

	function __construct (){

	  	$this->db="u238953651_acco";
    	
	}

	public function getId(){
		return $this->id;
	}

	
	public function getNumeroId(){
		return $this->NumeroId;
	}

	public function setNumeroId($NumeroId){
		$this->NumeroId = $NumeroId;
	}

	
	public function getDescripcion(){
		return $this->Descripcion;
	}

	public function setDescripcion($Descripcion){
		$this->Descripcion = $Descripcion;
	}

	
	public function getFechaVencimiento(){
		return $this->FechaVencimiento;
	}

	public function setFechaVencimiento($FechaVencimiento){
		$this->FechaVencimiento = $FechaVencimiento;
	}

	
	public function getCumplimiento(){
		return $this->Cumplimiento;
	}

	public function setCumplimiento($Cumplimiento){
		$this->Cumplimiento = $Cumplimiento;
	}

	
	public function getTipoAccion(){
		return $this->TipoAccion;
	}

	public function setTipoAccion($TipoAccion){
		$this->TipoAccion = $TipoAccion;
	}

	
	public function getCargadoPor(){
		return $this->CargadoPor;
	}

	public function setCargadoPor($CargadoPor){
		$this->CargadoPor = $CargadoPor;
	}

	
	public function getCantEquiGrupo(){
		return $this->CantEquiGrupo;
	}

	public function setCantEquiGrupo($CantEquiGrupo){
		$this->CantEquiGrupo = $CantEquiGrupo;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".AccionCorrectiva (NumeroId, Descripcion, FechaVencimiento, Cumplimiento, TipoAccion, CargadoPor, CantEquiGrupo) values(?, ?, ?, ?, ?, ?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array($this->NumeroId, $this->Descripcion, $this->FechaVencimiento, $this->Cumplimiento, $this->TipoAccion, $this->CargadoPor, $this->CantEquiGrupo));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$AccionCorrectivas = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".AccionCorrectiva";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$AccionCorrectiva = new AccionCorrectivaModel();
			
			$AccionCorrectiva->setNumeroId($row["NumeroId"]);
			$AccionCorrectiva->setDescripcion($row["Descripcion"]);
			$AccionCorrectiva->setFechaVencimiento($row["FechaVencimiento"]);
			$AccionCorrectiva->setCumplimiento($row["Cumplimiento"]);
			$AccionCorrectiva->setTipoAccion($row["TipoAccion"]);
			$AccionCorrectiva->setCargadoPor($row["CargadoPor"]);
			$AccionCorrectiva->setCantEquiGrupo($row["CantEquiGrupo"]);
		  	array_push ($AccionCorrectivas, new AccionCorrectivaModel($row["id"], 
		}
		Database::disconnect();
		return $AccionCorrectivas;
	}

	function read($id){
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".AccionCorrectiva WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$AccionCorrectiva = new AccionCorrectivaModel();
		
		$AccionCorrectiva->setNumeroId($row["NumeroId"]);
		$AccionCorrectiva->setDescripcion($row["Descripcion"]);
		$AccionCorrectiva->setFechaVencimiento($row["FechaVencimiento"]);
		$AccionCorrectiva->setCumplimiento($row["Cumplimiento"]);
		$AccionCorrectiva->setTipoAccion($row["TipoAccion"]);
		$AccionCorrectiva->setCargadoPor($row["CargadoPor"]);
		$AccionCorrectiva->setCantEquiGrupo($row["CantEquiGrupo"]);
		return $AccionCorrectiva;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".AccionCorrectiva WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".AccionCorrectiva SET NumeroId=?, Descripcion=?, FechaVencimiento=?, Cumplimiento=?, TipoAccion=?, CargadoPor=?, CantEquiGrupo=? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->NumeroId, $this->Descripcion, $this->FechaVencimiento, $this->Cumplimiento, $this->TipoAccion, $this->CargadoPor, $this->CantEquiGrupo, $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
