<?php
	include_once "database.php";

Class EquipoAfectadoModel {

	private $id;
	private $Equipo;
	private $AccionCorrectiva;
	private $Corregido;
	private	$db;

	function __construct (){

	  	$this->db="u238953651_acco";
    	
	}

	public function getId(){
		return $this->id;
	}

	
	public function getEquipo(){
		return $this->Equipo;
	}

	public function setEquipo($Equipo){
		$this->Equipo = $Equipo;
	}

	
	public function getAccionCorrectiva(){
		return $this->AccionCorrectiva;
	}

	public function setAccionCorrectiva($AccionCorrectiva){
		$this->AccionCorrectiva = $AccionCorrectiva;
	}

	
	public function getCorregido(){
		return $this->Corregido;
	}

	public function setCorregido($Corregido){
		$this->Corregido = $Corregido;
	}

	
  
	function create() {
    	
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO ".$this->db.".EquipoAfectado (Equipo, AccionCorrectiva, Corregido) values(?, ?, ?)";
		$q = $pdo->prepare($sql);
 		try {
			$q->execute(array($this->Equipo, $this->AccionCorrectiva, $this->Corregido));
			$this->id = $pdo->lastInsertId();
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			
			Database::disconnect();
			return $e->getCode();	
		}
	}


	function list(){

		$pdo = Database::connect();
		$EquipoAfectados = array();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".EquipoAfectado";
		$q = $pdo->prepare($sql);
		$q->execute();
		$results = $q->fetchAll();
		foreach ($results as $row) {
			$EquipoAfectado = new EquipoAfectadoModel();
			
			$EquipoAfectado->setEquipo($row["Equipo"]);
			$EquipoAfectado->setAccionCorrectiva($row["AccionCorrectiva"]);
			$EquipoAfectado->setCorregido($row["Corregido"]);
		  	array_push ($EquipoAfectados, new EquipoAfectadoModel($row["id"], 
		}
		Database::disconnect();
		return $EquipoAfectados;
	}

	function read($id){
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM ".$this->db.".EquipoAfectado WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$row = $q->fetch(PDO::FETCH_ASSOC);
		Database::disconnect();
		$EquipoAfectado = new EquipoAfectadoModel();
		
		$EquipoAfectado->setEquipo($row["Equipo"]);
		$EquipoAfectado->setAccionCorrectiva($row["AccionCorrectiva"]);
		$EquipoAfectado->setCorregido($row["Corregido"]);
		return $EquipoAfectado;
	}

	function delete($id){

		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM ".$this->db.".EquipoAfectado WHERE ID = ?";
		$q = $pdo->prepare($sql);
		try{
			$q->execute(array($id));
			Database::disconnect();
			return "";
		 } catch (Exception $e){
		 	Database::disconnect();
			return $e->getCode();
		}
		 
	}

	function update() {

    	$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE ".$this->db.".EquipoAfectado SET Equipo=?, AccionCorrectiva=?, Corregido=? WHERE id = ?";
		$q = $pdo->prepare($sql);
		try {
			$q->execute(array($this->Equipo, $this->AccionCorrectiva, $this->Corregido, $this->id));
			Database::disconnect();
			return "";
		} catch (Exception $e) {
			Database::disconnect();
			return $e->getCode();	
		}
	}


}
?>
