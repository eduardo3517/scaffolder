<?php
  
include '../md/UsuarioXTipoUsuarioModel.php';
include '../md/UsuarioModel.php';
include_once '../util/Messages.php';

class UsuarioXTipoUsuarioController{
    
	private $UsuarioXTipoUsuarioModel;
	private const SESSION_TAG = "IDUSUARIOSISTEMAU1P4";
    
	public function __CONSTRUCT(){
		$this->UsuarioXTipoUsuarioModel = new UsuarioXTipoUsuarioModel();
		if(!isset($_SESSION)) { 
			session_start();
		}
	}

	public function direccionar($c, $mensaje){
		if(!isset($_SESSION[$this::SESSION_TAG])){
			require_once "../vw/Templates/header.php";
			require_once "../vw/login.php";
			require_once "../vw/Templates/footer.php";
		} else {
			$UsuarioModel = new UsuarioModel();
			$UsuarioLogueado = $UsuarioModel->read($_SESSION[$this::SESSION_TAG]);
			$Permiso = $UsuarioModel->getPermissions($_SESSION[$this::SESSION_TAG], 17);

			if ($Permiso==-1){
				require_once "../vw/Templates/header.php";
				require_once "../vw/PaginaError.php";
				require_once "../vw/Templates/footer.php";
				
			} else {

				switch ($c){
					case "c":
						require_once "../vw/UsuarioXTipoUsuario/create.php";
					break;

					case "i":
						if (in_array(5, $Permiso)){
							
							require_once "../vw/UsuarioXTipoUsuario/index.php";
						}
					break;

					case "r":
						require_once "../vw/UsuarioXTipoUsuario/read.php";
					break;

					case "d":
						require_once "../vw/UsuarioXTipoUsuario/delete.php";
					break;

					case "u":
						require_once "../vw/UsuarioXTipoUsuario/update.php";
					break;

					case "b":
						$this->delete();
					break;

					case "g":
						$this->create();
					break;

					case "a":
						$this->update();
					break;

					default:
						header ("location: ../index.php");
					break;
					
				} 
			}
		}
	}
	
    
	public function list(){

        return $this->UsuarioXTipoUsuarioModel->list();
        
	}

	public function read($id){

        return $this->UsuarioXTipoUsuarioModel->read($id);
        
	}


	public function create(){
      
		
		$UsuarioXTipoUsuario = new UsuarioXTipoUsuarioModel();
		
		
		$UsuarioXTipoUsuario ->setUsuario(trim($_REQUEST["Usuario"]));
		$UsuarioXTipoUsuario ->setTipoUsuario(trim($_REQUEST["TipoUsuario"]));

		$message = $UsuarioXTipoUsuario->create(); 
		if ($message==23000){
			$this->direccionar("i",  Messages::DUPLICATED_CREATE_ERROR);
		} else if ($message != ""){
			$this->direccionar("i", Messages::GENERIC_ERROR.$message);
		} else {
			
			$this->direccionar("i", Messages::CREATE_SUCCESS);
		}
		
	}
                                    
	public function update(){

		$UsuarioXTipoUsuario = new UsuarioXTipoUsuarioModel();
		$UsuarioXTipoUsuario->setId("");
		
		$UsuarioXTipoUsuario ->setUsuario(trim($_REQUEST["Usuario"]));
		$UsuarioXTipoUsuario ->setTipoUsuario(trim($_REQUEST["TipoUsuario"]));
		$message = $UsuarioXTipoUsuario->update(); //realiza la operación de actualizado
		if ($message==23000){
			$this->direccionar("i", Messages::DUPLICATED_UPDATE_ERROR);
		} else if($message != ""){
			$this->direccionar("i", Messages::GENERIC_ERROR.$message);
		} else {
			$this->direccionar("i", Messages::UPDATE_SUCCESS);
		}
	}
    
	public function delete(){
		$id = trim($_REQUEST["id"]);
		$message = $this->UsuarioXTipoUsuarioModel->delete($id);
		if ($message==23000){
			$this->direccionar("i", Messages::RELATED_REG_DELETE_ERROR);
		} else if ($message!=""){
			$this->direccionar("i", Messages::GENERIC_ERROR.$message);
		} else {
			$this->direccionar("i", Messages::DELETE_SUCCESS);
		}
	}

	
}
 
$controladorUsuarioXTipoUsuario = new UsuarioXTipoUsuarioController();
$c="";
if(isset($_POST["c"])){
	$c=$_POST["c"];
} else {
	$c="i";
}
$controladorUsuarioXTipoUsuario->direccionar($c, "");

?>
