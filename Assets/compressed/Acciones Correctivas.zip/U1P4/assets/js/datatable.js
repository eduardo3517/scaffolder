
	$(document).ready(function () {
		
	$('#dtAccionCorrectiva').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtUsuario').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtEquipoAfectado').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtTipoAccionCorrectiva').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtTipoUsuario').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtOficinaVentas').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtEmplazamiento').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtRuta').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtCiudad').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtTipoEquipo').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtEquipo').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtEstadoEquipo').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtZona').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtSeguridad').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtEntidadSeguridad').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtAccionSeguridad').DataTable({
		"pagingType": "full_numbers" 
	});
	$('#dtUsuarioXTipoUsuario').DataTable({
		"pagingType": "full_numbers" 
	});
	$('.dataTables_length').addClass('bs-select');
});
